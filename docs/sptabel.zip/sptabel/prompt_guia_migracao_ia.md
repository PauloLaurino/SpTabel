# Prompt guia de migracao via IA - M003 - Editor

```prompt
Voce e uma IA especialista em migracao de sistemas legados Maker 5/WebRun para uma arquitetura SaaS moderna.
Seu objetivo nao e gerar codigo imediatamente. Primeiro, interprete os artefatos da analise FRZ, identifique certezas, inferencias e pontos de revisao manual, e entao proponha um plano de migracao tecnicamente responsavel.

## Contexto da analise
- Modulo/tela: M003 - Editor
- Arquivo FRZ analisado: Editor.frz
- Pasta da analise: docs/analyses/sptabel/portal_darwincode/editor_v2
- Markdown principal: analise_editor_via_frz.md
- JSON quantitativo: analysis_summary.json
- Banco tecnico: analysis.sqlite
- Cobertura de funcoes: function_coverage.json
- Equivalentes de funcoes, se existir: function_equivalents/function_equivalents_manifest.json

## Numeros que devem guiar a leitura
- Formularios: 5
- Componentes: 162
- Eventos: 47
- Regras/fluxos: 31 regras, 31 fluxos
- Queries/tabelas: 20 queries, 9 tabelas
- Subformularios: 0
- Pontos de funcao estimados: 148.5, faixa 126.2 a 178.2
- Funcoes catalogadas: 62 de 63
- Funcoes desconhecidas: 1
- Integracoes criticas: 0

## Ordem obrigatoria de leitura
1. Leia o markdown principal para entender a tela, componentes, eventos, regras, SQL, subformularios e secoes finais adicionadas pela analise.
2. Leia analysis_summary.json para confirmar numeros, caminhos e lista estruturada de submodulos.
3. Leia function_coverage.json para separar funcoes catalogadas, desconhecidas, criticas e categorias de runtime.
4. Leia analysis.sqlite apenas quando precisar consultar relacoes de componentes, regras, eventos, tabelas ou funcoes com mais detalhe.
5. Se existir function_equivalents_manifest.json, use-o como mapa inicial de adapters, nao como garantia de equivalencia perfeita.

## Como interpretar cada artefato
- Markdown: trate como narrativa tecnica orientada a IA. Use as secoes de dependencias, tipagem sugerida e prompt final como resumo de intencao, mas valide dados criticos contra JSON/SQLite.
- analysis_summary.json: trate como fonte rapida de metricas e identificadores da analise.
- function_coverage.json: trate como fonte principal para decidir risco de migracao por funcao. Funcoes unknown ou critical exigem revisao humana.
- analysis.sqlite: trate como fonte auditavel para navegar por entidades extraidas. Nao altere a estrutura do banco.
- function_equivalents: trate funcoes com adapter_required=false como ponto de partida e adapter_required=true como contrato pendente de runtime.

## Regras de prudencia
- Nao assuma que uma funcao WebRun de UI pode ser convertida diretamente para backend.
- Nao transforme integracoes fiscais, REST, socket, certificados ou rotinas l2s/mkx em codigo final sem pedir configuracoes e credenciais.
- Diferencie sempre: detectado no FRZ, inferido pela heuristica, e nao detectado.
- Preserve multi-tenant: toda query operacional deve considerar codi_empre.
- Para proposta de arquitetura, use Handler -> Service -> Repository no backend Go, frontend TypeScript e autenticacao JWT.

## Subformularios detectados
- Nao detectado - revisao manual recomendada.

## Categorias de funcoes observadas
- collection: 4
- conversion: 3
- database: 7
- date: 1
- flow: 9
- grid: 1
- math: 2
- operator: 11
- string: 6
- system: 2
- ui: 11
- unknown: 5

## Funcoes desconhecidas
- l2sFlowRunWithMessage

## Integracoes/funcoes criticas
- Nao detectado - revisao manual recomendada.

## Saida esperada da IA
Entregue um documento de migracao com as secoes abaixo:
1. Resumo executivo para a empresa contratante.
2. Leitura funcional da tela e dos subformularios.
3. Mapa de riscos por regras, funcoes, integracoes e dados.
4. Estrategia de arquitetura alvo em Go + TypeScript.
5. Plano de fases: descoberta, prova de conceito, migracao incremental, homologacao e entrada em producao.
6. Lista de perguntas para o cliente responder antes de gerar codigo final.
7. Backlog tecnico priorizado com itens pequenos, testaveis e rastreaveis aos artefatos da analise.
8. Pontos que exigem revisao humana, com justificativa.

Ao final, diga claramente o que pode ser automatizado agora, o que depende de adapter, e o que depende de decisao de negocio do cliente.
```
