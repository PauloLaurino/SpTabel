# Guia Avancado: Como uma IA deve analisar artefatos FRZ e gerar documentacao + Mock fiel

Este documento ensina uma IA a executar uma analise tecnica completa de modulos exportados do Maker 5/WebRun e a produzir dois entregaveis de alta qualidade:

1. **Documento de migracao** com 8 secoes, orientado a plano tecnico responsavel
2. **Mock HTML navegavel** fiel a interface real da tela

---

## Contexto desta analise

- Modulo: M003 - Editor
- FRZ: Editor.frz
- Pasta: docs/analyses/sptabel/portal_darwincode/editor_v2
- Perfil de mock sugerido: fiscal_nfe
- Metricas: formularios=5, componentes=162, eventos=47, regras=31, fluxos=31, queries=20, tabelas=9, subformularios=0, PF=148.5.
- Funcoes: 63 totais, 62 catalogadas, 1 desconhecidas, 0 criticas.

---

## PARTE 1 - Como analisar os artefatos

### 1.1 Ordem de leitura obrigatoria

Leia os artefatos nesta sequencia. Cada leitura deve construir sobre a anterior.

```text
1. analysis_summary.json              -> contexto numerico e lista de submodulos
2. function_coverage.json             -> mapa de riscos por funcao
3. Markdown principal                 -> narrativa funcional profunda
4. function_equivalents_manifest.json -> adapter_required por funcao
5. analysis.sqlite                    -> consultas pontuais de relacionamento
```

Nunca inverta essa ordem. O JSON da o mapa; o Markdown da o territorio.

### 1.2 O que extrair do analysis_summary.json

Este arquivo e sua ancora quantitativa. Extraia:

- Metricas brutas: TotalForms, TotalComponents, TotalEvents, TotalRules, TotalFlows, TotalQueries, TotalTables, TotalSubmodules.
- Estimativa de porte: EstimatedFunctionPts, EstimatedLower, EstimatedUpper. Use como guia de complexidade, nao como SLA.
- Submodulos detectados: Nome, FormularioOrigem, CampoVinculo, CargaDinamica, EhSubformulario, eventos e RequerMigracaoManual.
- Funcoes desconhecidas: ProbableOrigin, Contexts e RuleNames.

Regra: toda funcao com ProbableOrigin diferente de native deve entrar no mapa de riscos.

### 1.3 O que extrair do function_coverage.json

Para cada funcao, avalie status, match.category, match.layer, criticality, occurrences e rule_names. Cruze com o manifest para saber se adapter_required=true.

| Categoria | Estrategia de migracao |
|---|---|
|string, math, operator, conversion|Implementar diretamente; validar parametros reais.|
|collection|Implementar como slice/array em Go ou Array em TypeScript.|
|database|Migrar para Repository com SQL explicito.|
|ui|Adapter de frontend, estado React ou DOM API.|
|flow|Adapter assincrono: goroutine/channel em Go, async/await em TS.|
|grid|Tabela com selecao, evento e endpoint filho.|
|system|Avaliar caso a caso; timer tende a virar SSE/WebSocket push.|
|security|JWT claims e middleware; nunca copiar sessao WebRun literalmente.|
|integration|Bloquear ate ter credenciais, endpoint e contrato.|
|unknown|Bloquear ate obter codigo-fonte ou especificacao.|

### 1.4 Como ler o Markdown principal - 5 passagens

1. Estrutura da tela: tabela principal, SQL, campos, chaves, categorias de componentes.
2. Grids e subformularios: vinculos, eventos, carga dinamica e filtros que viram endpoints filhos.
3. Eventos por componente: fluxo tecnico, funcoes usadas, CALLRULE, ebfAsyncJavaFlowExecute e ebfChannelExecuteRuleOnForm.
4. Queries: cada query vira Repository; parametros de sessao viram claims JWT ou contexto de request.
5. Funcoes desconhecidas no contexto: leia antes/depois da chamada para inferir contrato, retorno e efeito colateral.

### 1.5 Como usar function_equivalents_manifest.json

- adapter_required=false: ponto de partida seguro, ainda exige validar parametros reais.
- adapter_required=true: criar adapter explicito antes de usar em producao.
- O manifest nao garante equivalencia perfeita; e um rascunho inicial.

### 1.6 Como identificar o que a tela realmente faz

Responda: quem usa a tela, qual e o objeto central, qual e o ciclo de vida, o que atualiza em tempo real, quais integracoes existem, quais acoes sao destrutivas ou irreversiveis.

### 1.7 Como montar o mapa de riscos

Alto: funcoes desconhecidas custom/third-party, submodulos dinamicos sem vinculo, integracoes sem credenciais, regras desconhecidas com revisao manual, sessoes WebRun sem equivalente claro.
Medio: adapter_required=true, CALLRULE fora do FRZ, queries com parametros de sessao, multiplas chamadas assincronas encadeadas.
Baixo: funcoes triviais, grids com vinculo claro, botoes que abrem formulario, leitura simples de sessao.

---

## PARTE 2 - Como produzir o documento de migracao

Estrutura obrigatoria:

```text
1. Resumo executivo
2. Leitura funcional da tela e subformularios
3. Mapa de riscos por funcoes, regras, integracoes e dados
4. Estrategia de arquitetura alvo
5. Plano de fases
6. Perguntas ao cliente
7. Backlog tecnico priorizado
8. Pontos que exigem revisao humana
```

Regras: escreva o resumo para nao-tecnicos; organize a leitura funcional por areas de uso; use tabelas no mapa de riscos; arquitetura alvo deve usar Go Handler -> Service -> Repository, frontend TypeScript, JWT com empresa_id/operador_id e multi-tenant obrigatorio; plano em fases deve ir de descoberta ate producao; perguntas ao cliente devem ser rastreaveis aos artefatos; backlog deve ser P0 a P4 com pontos 1-5; revisao humana deve ter justificativa e responsavel.

---

## PARTE 3 - Como gerar o Mock HTML fiel

Principio fundamental: o mock nao e um prototipo de componentes. E uma simulacao da sessao de trabalho real do usuario.

### 3.1 Heuristica de tipo de tela

| Padrao detectado | Tipo de interface |
|---|---|
|Muitos buttons + html_runtime + timer|Painel operacional/dashboard.|
|grid principal + muitos campos + lookup|CRUD de cadastro.|
|upload + textarea + envio|Comunicacao/chat.|
|gridFilaDeEspera/gridEmAtendimento/gridPotenciais|Painel de atendimento multicanal.|
|itens/parcelas/cliente/venda|Pedido ou venda com itens e totais.|
|SEFAZ/NFe/fiscal|Operacao fiscal com status e integracoes.|

### 3.2 Mapeamento FRZ -> HTML

| Componente FRZ | Elemento HTML sugerido |
|---|---|
|button bot/Btn|button com label de negocio.|
|grid/submodulo com clique|item selecionavel, tabela ou fila lateral.|
|grid com duplo clique|tabela interativa com dblclick.|
|textarea txtMensagem|textarea com auto-resize e envio por Enter.|
|upload|botao de anexo com preview.|
|html_runtime|div de conteudo customizado.|
|timer|setInterval com feedback visual.|
|lookup|select ou combobox.|
|lbl/campos display|cards de informacao.|
|container cont_|painel colapsavel ou secao.|

### 3.3 Padrões de UX obrigatorios

- CSS com variaveis, reset minimo, contraste e estados hover/focus.
- Toda acao deve responder com toast, mudanca de estado ou confirmacao.
- Dados simulados devem pertencer ao dominio, nunca Lorem ipsum.
- Selecionar item em grid deve carregar detalhe.
- Submeter formulario deve alterar algo visivel.
- Acoes destrutivas devem usar confirm().
- Timer, toggle de gravacao, abas, busca e tags devem funcionar quando existirem evidencias no FRZ.

### 3.4 Checklist antes de entregar o mock

- Abrir sem erros no console.
- Selecionar item de grade/fila carrega detalhe.
- Enter envia mensagem ou submete acao simulada.
- Transferir/finalizar pedem confirmacao quando aplicavel.
- Abas e paineis alternam sem quebrar layout.
- Timer incrementa se houver comportamento de timer.
- Layout nao quebra em 1200px.

---

## PARTE 4 - Resumo executivo para a IA

Etapa 1: leia summary e coverage integralmente. Etapa 2: leia o Markdown nas 5 passagens. Etapa 3: produza o documento nas 8 secoes. Etapa 4: gere mock HTML fiel ao perfil da tela, com CSS e JS embutidos.

## Apendice - Anti-padroes

| Anti-padrao | Correto |
|---|---|
|Gerar codigo antes do plano|Primeiro plano, depois codigo.|
|Mock sem interatividade|Selecionar, enviar, alternar abas e mostrar toast.|
|Dados genericos|Dados do dominio real.|
|Tratar unknown como inexistente|Perguntar ao cliente ou fornecedor.|
|Copiar sessao WebRun como global|JWT claims, request context ou cache por usuario.|
|Converter evento de formulario pai em REST simples|WebSocket/evento para area pai quando necessario.|
