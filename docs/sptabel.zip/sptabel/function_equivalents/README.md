# Pacote de equivalentes de funcoes - M003 - Editor

- Arquivo FRZ: `Editor.frz`
- Funcoes no pacote: `63`
- Funcoes que exigem adapter: `36`

Arquivos gerados:

- `function_equivalents.go`: base para backend Go.
- `function_equivalents.ts`: base para frontend ou servicos TypeScript.
- `function_equivalents.py`: base para validadores, ETL ou testes em Python.
- `function_equivalents_manifest.json`: metadados, categoria, criticidade e necessidade de adapter.

Observacao: funcoes de UI, banco, fluxo, fiscal e integracao nao devem executar diretamente sem adapter do novo runtime.
