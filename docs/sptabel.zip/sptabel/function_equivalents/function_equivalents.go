package equivalents

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
)

// FunctionMeta descreve uma funcao Maker/WebRun detectada no FRZ.
type FunctionMeta struct {
	Name string
	Category string
	Layer string
	Status string
	AdapterRequired bool
	Description string
}

// Catalog contem as funcoes usadas pelo modulo analisado.
var Catalog = map[string]FunctionMeta{
	"ebfappend": {Name: "ebfAppend", Category: "collection", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Junta vários itens de texto em apenas um item."},
	"ebfchangecomponentvalueotherform": {Name: "ebfChangeComponentValueOtherForm", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Altera o valor de um componente que esteja em outro formulário que não o corrente."},
	"ebfcloseform": {Name: "ebfCloseForm", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Essa função é utilizada para fechar o formulário que chama o fluxo."},
	"ebfconcat": {Name: "ebfConcat", Category: "string", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Junta vários itens de texto em apenas um item."},
	"ebfformatdatetime": {Name: "ebfFormatDateTime", Category: "date", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função modifica a formatação da data passada no primeiro parâmetro para a formatação passada no segundo parâmetro."},
	"ebfformchangecomponentvalue": {Name: "ebfFormChangeComponentValue", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "A função altera o conteúdo do componente que está no formulário passado como parâmetro pelo conteúdo passado no 3º parâmetro."},
	"ebfformgetcomponentvalue": {Name: "ebfFormGetComponentValue", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Obtém o conteúdo do componente passado no segundo parâmetro e o retorna."},
	"ebfformgetlookupname": {Name: "ebfFormGetLookupName", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Função que obtém o valor exibido na lista dinâmica."},
	"ebfformopenfilteredform": {Name: "ebfFormOpenFilteredForm", Category: "ui", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "Form Open Filtered Form"},
	"ebfformopenform": {Name: "ebfFormOpenForm", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Abre o formulário passado por parâmetro."},
	"ebfformrefreshcomponent": {Name: "ebfFormRefreshComponent", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Atualiza o conteúdo do componente passado por parâmetro."},
	"ebfformsetenabled": {Name: "ebfFormSetEnabled", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Esta função habilita o componente se a condição passada no segundo parâmetro for verdadeira, ou desabilita caso a condição seja falsa. Se o componente estiver desabilitado, não será possível modificar seu conteúdo."},
	"ebfformsetfocus": {Name: "ebfFormSetFocus", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Essa função é utilizada para focar um determinado componente passado como parâmetro."},
	"ebfformsetlookupname": {Name: "ebfFormSetLookupName", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Função que altera o valor exibido na lista dinâmica."},
	"ebfformsetvisible": {Name: "ebfFormSetVisible", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Esta função mostra o componente se a condição passada no segundo parâmetro for verdadeira ou oculta caso a condição seja falsa."},
	"ebfgetcomponentvaluefromotherform": {Name: "ebfGetComponentValueFromOtherForm", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Nao detectado - revisao manual recomendada"},
	"ebfgetelementfromlist": {Name: "ebfGetElementFromList", Category: "collection", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função busca e retorna o elemento que deseja obter, a partir da sua posição na lista."},
	"ebfgetformresultset": {Name: "ebfGetFormResultset", Category: "ui", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "Get Form Resultset"},
	"ebfgetsessionattribute": {Name: "ebfGetSessionAttribute", Category: "math", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Obtém o conteúdo da variável criada pela função \"Definir variável de sessão\" passando no 1º parâmetro o nome da variável e no 2º parâmetro o valor lógico verdadeiro ou falso, indicando se é ou não uma variável global. Para variáveis"},
	"ebfgetusercode": {Name: "ebfGetUserCode", Category: "system", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "Get User Code"},
	"ebfgridgetvalue": {Name: "ebfGridGetValue", Category: "grid", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Essa função retorna o valor que está na Grade, a partir da informação da linha (a primeira linha da Grade é a linha \"0\" (zero)) e a coluna que deseja obter o valor."},
	"ebfgroupboxshowcomponents": {Name: "ebfGroupBoxShowComponents", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Esta função mostra ou oculta o componente moldura e todos os componentes que estiverem \"dentro\" da área do mesmo."},
	"ebfhtmlremovechild": {Name: "ebfHtmlRemoveChild", Category: "unknown", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Esta função remove o filho de um elemento especificado por parâmetro."},
	"ebfindexof": {Name: "ebfIndexOf", Category: "unknown", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Esta função localiza o conteúdo do 2° parâmetro dentro do conteúdo do primeiro parâmetro."},
	"ebflength": {Name: "ebfLength", Category: "unknown", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "A função recebe um texto e retorna o tamanho do mesmo."},
	"ebflistlength": {Name: "ebfListLength", Category: "collection", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função retorna o tamanho da lista, ou seja, a quantidade de elementos que pertencem à lista."},
	"ebflistparamscreate": {Name: "ebfListParamsCreate", Category: "collection", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função cria uma lista com todos os valores que foram passados pelos parâmetros."},
	"ebfnewline": {Name: "ebfNewLine", Category: "unknown", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Usado para quebrar a linha (pular linha) em um texto, onde o parâmetro recebido será a quantidade de linhas à serem puladas."},
	"ebfrefreshcomponentotherform": {Name: "ebfRefreshComponentOtherForm", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Atualiza o componente em outro formulário."},
	"ebfremovesessionattribute": {Name: "ebfRemoveSessionAttribute", Category: "math", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Remove a variável de sessão passando no 1º parâmetro o nome da variável e no 2º o valor Lógico que indica se ela é ou não global."},
	"ebfreplace": {Name: "ebfReplace", Category: "string", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "A função localiza o 2º parâmetro dentro do texto e o substitui pelo conteúdo passado no 3º parâmetro."},
	"ebfreplaceall": {Name: "ebfReplaceAll", Category: "string", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Esta função localiza todas as subsequências iguais ao 2º parâmetro dentro do texto e os substituem pelo conteúdo passado no 3º parâmetro."},
	"ebfresultsetabsolute": {Name: "ebfResultSetAbsolute", Category: "system", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "Result Set Absolute"},
	"ebfrichtextinserttextatposition": {Name: "ebfRichTextInsertTextAtPosition", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Insere um texto na posição do cursor em um Texto Rico."},
	"ebfsearchsubstring": {Name: "ebfSearchSubstring", Category: "string", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Esta função procura dentro do 1° parâmetro a subsequência passada no 2º parâmetro."},
	"ebfsetsessionattribute": {Name: "ebfSetSessionAttribute", Category: "ui", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "As variáveis de sessão são utilizadas quando houver a necessidade de ter uma variável que se mantém para regras diferentes. Variáveis de sessão não globais se mantém de acordo com o usuário e as globais se mantém para todo usuário."},
	"ebfsqlclose": {Name: "ebfSQLClose", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L Close"},
	"ebfsqlcommittransaction": {Name: "ebfSQLCommitTransaction", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L Commit Transaction"},
	"ebfsqleof": {Name: "ebfSQLEOF", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L E O F"},
	"ebfsqlexecutequery": {Name: "ebfSQLExecuteQuery", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L Execute Query"},
	"ebfsqlexecuteupdate": {Name: "ebfSQLExecuteUpdate", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L Execute Update"},
	"ebfsqlfield": {Name: "ebfSQLField", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L Field"},
	"ebfsqlgetfieldfromform": {Name: "ebfSQLGetFieldFromForm", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Obtém o conteúdo de um componente do formulário principal ou de qualquer outro passado por parâmetro."},
	"ebfsqlnext": {Name: "ebfSQLNext", Category: "database", Layer: "server", Status: "cataloged", AdapterRequired: true, Description: "S Q L Next"},
	"ebfstopruleexecution": {Name: "ebfStopRuleExecution", Category: "flow", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Interrompe a execução do fluxo. Caso seja passado alguma mensagem por parâmetro, esta é exibida. Se houver algum processamento após a utilização dessa função, este não será executado."},
	"ebfsubstring": {Name: "ebfSubstring", Category: "string", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "A função recebe um texto (1º parâmetro) e retorna uma subsequência deste texto. A subsequência inicia na posição indicada no 2º parâmetro, com o tamanho indicado no 3º parâmetro."},
	"ebfsubstringinverse": {Name: "ebfSubstringInverse", Category: "string", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "A função recebe um texto (primeiro parâmetro) e retorna apenas a quantidade de caracteres passada no segundo"},
	"ebftrim": {Name: "ebfTrim", Category: "unknown", Layer: "client", Status: "cataloged", AdapterRequired: true, Description: "Remove os espaços existentes antes e depois do texto passado por parâmetro e retorna."},
	"isequal": {Name: "isEqual", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se os valores passados por parâmetro são iguais, ou seja, possuem o mesmo valor."},
	"isgreater": {Name: "isGreater", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se o valor do 1º parâmetro é maior que o do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso. Se os valores dos parâmetros forem iguais o retorno será falso, pois o mesmo valor não é maior que ele mesmo."},
	"isminor": {Name: "isMinor", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se o valor do 1º parâmetro é menor que o valor do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso. Se os valores dos parâmetros forem iguais o retorno será falso, pois o mesmo valor não é menor que ele mesmo."},
	"isminororequal": {Name: "isMinorOrEqual", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se o valor do 1º parâmetro é menor ou igual ao valor do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso."},
	"isnullorempty": {Name: "isNullOrEmpty", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se o parâmetro é nulo ou vazio. A depender do resultado, retorna verdadeiro ou falso."},
	"l2sflowrunwithmessage": {Name: "l2sFlowRunWithMessage", Category: "unknown", Layer: "unknown", Status: "unknown", AdapterRequired: true, Description: "Nao detectado - revisao manual recomendada."},
	"opradd": {Name: "oprAdd", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Retorna a soma dos números passados por parâmetros."},
	"oprand": {Name: "oprAnd", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se algum valor passado é Falso, para retornar falso ou se são verdadeiros para retornar verdadeiro."},
	"oprif": {Name: "oprIf", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica o valor lógico do 1º parâmetro, se o mesmo for verdadeiro o retorno será o valor que estiver no 2º"},
	"oprnot": {Name: "oprNot", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função inverte o valor lógico. Se o valor do parâmetro for verdadeiro o retorno dele terá o valor lógico falso. Caso contrário será verdadeiro."},
	"opror": {Name: "oprOr", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Essa função verifica se algum valor passado por parâmetro é verdadeiro, para retornar verdadeiro ou se todos os parâmetros são valores falsos, para retornar falso."},
	"oprsubtract": {Name: "oprSubtract", Category: "operator", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Subtração de valores informados nos parâmetros."},
	"todouble": {Name: "toDouble", Category: "conversion", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Converte para fracionado o valor passado por parâmetro."},
	"tolong": {Name: "toLong", Category: "conversion", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Converte um valor passado por parâmetro para Inteiro."},
	"tostring": {Name: "toString", Category: "conversion", Layer: "client", Status: "cataloged", AdapterRequired: false, Description: "Converte um valor passado por parâmetro para letras."},
}

// CallMakerEquivalent chama o equivalente local quando ele existir.
func CallMakerEquivalent(name string, args ...any) (any, error) {
	switch strings.ToLower(strings.TrimSpace(name)) {
	case "ebfappend":
		return EbfAppend(args...)
	case "ebfchangecomponentvalueotherform":
		return EbfChangeComponentValueOtherForm(args...)
	case "ebfcloseform":
		return EbfCloseForm(args...)
	case "ebfconcat":
		return EbfConcat(args...)
	case "ebfformatdatetime":
		return EbfFormatDateTime(args...)
	case "ebfformchangecomponentvalue":
		return EbfFormChangeComponentValue(args...)
	case "ebfformgetcomponentvalue":
		return EbfFormGetComponentValue(args...)
	case "ebfformgetlookupname":
		return EbfFormGetLookupName(args...)
	case "ebfformopenfilteredform":
		return EbfFormOpenFilteredForm(args...)
	case "ebfformopenform":
		return EbfFormOpenForm(args...)
	case "ebfformrefreshcomponent":
		return EbfFormRefreshComponent(args...)
	case "ebfformsetenabled":
		return EbfFormSetEnabled(args...)
	case "ebfformsetfocus":
		return EbfFormSetFocus(args...)
	case "ebfformsetlookupname":
		return EbfFormSetLookupName(args...)
	case "ebfformsetvisible":
		return EbfFormSetVisible(args...)
	case "ebfgetcomponentvaluefromotherform":
		return EbfGetComponentValueFromOtherForm(args...)
	case "ebfgetelementfromlist":
		return EbfGetElementFromList(args...)
	case "ebfgetformresultset":
		return EbfGetFormResultset(args...)
	case "ebfgetsessionattribute":
		return EbfGetSessionAttribute(args...)
	case "ebfgetusercode":
		return EbfGetUserCode(args...)
	case "ebfgridgetvalue":
		return EbfGridGetValue(args...)
	case "ebfgroupboxshowcomponents":
		return EbfGroupBoxShowComponents(args...)
	case "ebfhtmlremovechild":
		return EbfHtmlRemoveChild(args...)
	case "ebfindexof":
		return EbfIndexOf(args...)
	case "ebflength":
		return EbfLength(args...)
	case "ebflistlength":
		return EbfListLength(args...)
	case "ebflistparamscreate":
		return EbfListParamsCreate(args...)
	case "ebfnewline":
		return EbfNewLine(args...)
	case "ebfrefreshcomponentotherform":
		return EbfRefreshComponentOtherForm(args...)
	case "ebfremovesessionattribute":
		return EbfRemoveSessionAttribute(args...)
	case "ebfreplace":
		return EbfReplace(args...)
	case "ebfreplaceall":
		return EbfReplaceAll(args...)
	case "ebfresultsetabsolute":
		return EbfResultSetAbsolute(args...)
	case "ebfrichtextinserttextatposition":
		return EbfRichTextInsertTextAtPosition(args...)
	case "ebfsearchsubstring":
		return EbfSearchSubstring(args...)
	case "ebfsetsessionattribute":
		return EbfSetSessionAttribute(args...)
	case "ebfsqlclose":
		return EbfSQLClose(args...)
	case "ebfsqlcommittransaction":
		return EbfSQLCommitTransaction(args...)
	case "ebfsqleof":
		return EbfSQLEOF(args...)
	case "ebfsqlexecutequery":
		return EbfSQLExecuteQuery(args...)
	case "ebfsqlexecuteupdate":
		return EbfSQLExecuteUpdate(args...)
	case "ebfsqlfield":
		return EbfSQLField(args...)
	case "ebfsqlgetfieldfromform":
		return EbfSQLGetFieldFromForm(args...)
	case "ebfsqlnext":
		return EbfSQLNext(args...)
	case "ebfstopruleexecution":
		return EbfStopRuleExecution(args...)
	case "ebfsubstring":
		return EbfSubstring(args...)
	case "ebfsubstringinverse":
		return EbfSubstringInverse(args...)
	case "ebftrim":
		return EbfTrim(args...)
	case "isequal":
		return IsEqual(args...)
	case "isgreater":
		return IsGreater(args...)
	case "isminor":
		return IsMinor(args...)
	case "isminororequal":
		return IsMinorOrEqual(args...)
	case "isnullorempty":
		return IsNullOrEmpty(args...)
	case "l2sflowrunwithmessage":
		return L2sFlowRunWithMessage(args...)
	case "opradd":
		return OprAdd(args...)
	case "oprand":
		return OprAnd(args...)
	case "oprif":
		return OprIf(args...)
	case "oprnot":
		return OprNot(args...)
	case "opror":
		return OprOr(args...)
	case "oprsubtract":
		return OprSubtract(args...)
	case "todouble":
		return ToDouble(args...)
	case "tolong":
		return ToLong(args...)
	case "tostring":
		return ToString(args...)
	default:
		return nil, fmt.Errorf("funcao Maker nao catalogada: %s", name)
	}
}

// EbfAppend equivale a ebfAppend. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfAppend(args ...any) (any, error) {
	return evaluateByCategory("ebfAppend", "collection", false, args...)
}

// EbfChangeComponentValueOtherForm equivale a ebfChangeComponentValueOtherForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfChangeComponentValueOtherForm(args ...any) (any, error) {
	return evaluateByCategory("ebfChangeComponentValueOtherForm", "ui", true, args...)
}

// EbfCloseForm equivale a ebfCloseForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfCloseForm(args ...any) (any, error) {
	return evaluateByCategory("ebfCloseForm", "flow", true, args...)
}

// EbfConcat equivale a ebfConcat. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfConcat(args ...any) (any, error) {
	return evaluateByCategory("ebfConcat", "string", false, args...)
}

// EbfFormatDateTime equivale a ebfFormatDateTime. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfFormatDateTime(args ...any) (any, error) {
	return evaluateByCategory("ebfFormatDateTime", "date", false, args...)
}

// EbfFormChangeComponentValue equivale a ebfFormChangeComponentValue. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormChangeComponentValue(args ...any) (any, error) {
	return evaluateByCategory("ebfFormChangeComponentValue", "flow", true, args...)
}

// EbfFormGetComponentValue equivale a ebfFormGetComponentValue. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormGetComponentValue(args ...any) (any, error) {
	return evaluateByCategory("ebfFormGetComponentValue", "flow", true, args...)
}

// EbfFormGetLookupName equivale a ebfFormGetLookupName. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormGetLookupName(args ...any) (any, error) {
	return evaluateByCategory("ebfFormGetLookupName", "ui", true, args...)
}

// EbfFormOpenFilteredForm equivale a ebfFormOpenFilteredForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormOpenFilteredForm(args ...any) (any, error) {
	return evaluateByCategory("ebfFormOpenFilteredForm", "ui", true, args...)
}

// EbfFormOpenForm equivale a ebfFormOpenForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormOpenForm(args ...any) (any, error) {
	return evaluateByCategory("ebfFormOpenForm", "ui", true, args...)
}

// EbfFormRefreshComponent equivale a ebfFormRefreshComponent. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormRefreshComponent(args ...any) (any, error) {
	return evaluateByCategory("ebfFormRefreshComponent", "flow", true, args...)
}

// EbfFormSetEnabled equivale a ebfFormSetEnabled. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormSetEnabled(args ...any) (any, error) {
	return evaluateByCategory("ebfFormSetEnabled", "flow", true, args...)
}

// EbfFormSetFocus equivale a ebfFormSetFocus. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormSetFocus(args ...any) (any, error) {
	return evaluateByCategory("ebfFormSetFocus", "flow", true, args...)
}

// EbfFormSetLookupName equivale a ebfFormSetLookupName. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormSetLookupName(args ...any) (any, error) {
	return evaluateByCategory("ebfFormSetLookupName", "ui", true, args...)
}

// EbfFormSetVisible equivale a ebfFormSetVisible. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfFormSetVisible(args ...any) (any, error) {
	return evaluateByCategory("ebfFormSetVisible", "flow", true, args...)
}

// EbfGetComponentValueFromOtherForm equivale a ebfGetComponentValueFromOtherForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfGetComponentValueFromOtherForm(args ...any) (any, error) {
	return evaluateByCategory("ebfGetComponentValueFromOtherForm", "ui", true, args...)
}

// EbfGetElementFromList equivale a ebfGetElementFromList. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfGetElementFromList(args ...any) (any, error) {
	return evaluateByCategory("ebfGetElementFromList", "collection", false, args...)
}

// EbfGetFormResultset equivale a ebfGetFormResultset. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfGetFormResultset(args ...any) (any, error) {
	return evaluateByCategory("ebfGetFormResultset", "ui", true, args...)
}

// EbfGetSessionAttribute equivale a ebfGetSessionAttribute. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfGetSessionAttribute(args ...any) (any, error) {
	return evaluateByCategory("ebfGetSessionAttribute", "math", false, args...)
}

// EbfGetUserCode equivale a ebfGetUserCode. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfGetUserCode(args ...any) (any, error) {
	return evaluateByCategory("ebfGetUserCode", "system", true, args...)
}

// EbfGridGetValue equivale a ebfGridGetValue. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfGridGetValue(args ...any) (any, error) {
	return evaluateByCategory("ebfGridGetValue", "grid", true, args...)
}

// EbfGroupBoxShowComponents equivale a ebfGroupBoxShowComponents. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfGroupBoxShowComponents(args ...any) (any, error) {
	return evaluateByCategory("ebfGroupBoxShowComponents", "ui", true, args...)
}

// EbfHtmlRemoveChild equivale a ebfHtmlRemoveChild. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfHtmlRemoveChild(args ...any) (any, error) {
	return evaluateByCategory("ebfHtmlRemoveChild", "unknown", true, args...)
}

// EbfIndexOf equivale a ebfIndexOf. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfIndexOf(args ...any) (any, error) {
	return evaluateByCategory("ebfIndexOf", "unknown", true, args...)
}

// EbfLength equivale a ebfLength. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfLength(args ...any) (any, error) {
	return evaluateByCategory("ebfLength", "unknown", true, args...)
}

// EbfListLength equivale a ebfListLength. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfListLength(args ...any) (any, error) {
	return evaluateByCategory("ebfListLength", "collection", false, args...)
}

// EbfListParamsCreate equivale a ebfListParamsCreate. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfListParamsCreate(args ...any) (any, error) {
	return evaluateByCategory("ebfListParamsCreate", "collection", false, args...)
}

// EbfNewLine equivale a ebfNewLine. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfNewLine(args ...any) (any, error) {
	return evaluateByCategory("ebfNewLine", "unknown", true, args...)
}

// EbfRefreshComponentOtherForm equivale a ebfRefreshComponentOtherForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfRefreshComponentOtherForm(args ...any) (any, error) {
	return evaluateByCategory("ebfRefreshComponentOtherForm", "ui", true, args...)
}

// EbfRemoveSessionAttribute equivale a ebfRemoveSessionAttribute. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfRemoveSessionAttribute(args ...any) (any, error) {
	return evaluateByCategory("ebfRemoveSessionAttribute", "math", false, args...)
}

// EbfReplace equivale a ebfReplace. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfReplace(args ...any) (any, error) {
	return evaluateByCategory("ebfReplace", "string", false, args...)
}

// EbfReplaceAll equivale a ebfReplaceAll. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfReplaceAll(args ...any) (any, error) {
	return evaluateByCategory("ebfReplaceAll", "string", false, args...)
}

// EbfResultSetAbsolute equivale a ebfResultSetAbsolute. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfResultSetAbsolute(args ...any) (any, error) {
	return evaluateByCategory("ebfResultSetAbsolute", "system", true, args...)
}

// EbfRichTextInsertTextAtPosition equivale a ebfRichTextInsertTextAtPosition. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfRichTextInsertTextAtPosition(args ...any) (any, error) {
	return evaluateByCategory("ebfRichTextInsertTextAtPosition", "ui", true, args...)
}

// EbfSearchSubstring equivale a ebfSearchSubstring. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfSearchSubstring(args ...any) (any, error) {
	return evaluateByCategory("ebfSearchSubstring", "string", false, args...)
}

// EbfSetSessionAttribute equivale a ebfSetSessionAttribute. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSetSessionAttribute(args ...any) (any, error) {
	return evaluateByCategory("ebfSetSessionAttribute", "ui", true, args...)
}

// EbfSQLClose equivale a ebfSQLClose. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLClose(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLClose", "database", true, args...)
}

// EbfSQLCommitTransaction equivale a ebfSQLCommitTransaction. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLCommitTransaction(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLCommitTransaction", "database", true, args...)
}

// EbfSQLEOF equivale a ebfSQLEOF. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLEOF(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLEOF", "database", true, args...)
}

// EbfSQLExecuteQuery equivale a ebfSQLExecuteQuery. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLExecuteQuery(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLExecuteQuery", "database", true, args...)
}

// EbfSQLExecuteUpdate equivale a ebfSQLExecuteUpdate. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLExecuteUpdate(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLExecuteUpdate", "database", true, args...)
}

// EbfSQLField equivale a ebfSQLField. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLField(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLField", "database", true, args...)
}

// EbfSQLGetFieldFromForm equivale a ebfSQLGetFieldFromForm. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLGetFieldFromForm(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLGetFieldFromForm", "flow", true, args...)
}

// EbfSQLNext equivale a ebfSQLNext. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfSQLNext(args ...any) (any, error) {
	return evaluateByCategory("ebfSQLNext", "database", true, args...)
}

// EbfStopRuleExecution equivale a ebfStopRuleExecution. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfStopRuleExecution(args ...any) (any, error) {
	return evaluateByCategory("ebfStopRuleExecution", "flow", true, args...)
}

// EbfSubstring equivale a ebfSubstring. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfSubstring(args ...any) (any, error) {
	return evaluateByCategory("ebfSubstring", "string", false, args...)
}

// EbfSubstringInverse equivale a ebfSubstringInverse. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func EbfSubstringInverse(args ...any) (any, error) {
	return evaluateByCategory("ebfSubstringInverse", "string", false, args...)
}

// EbfTrim equivale a ebfTrim. Criar adapter conectado ao runtime novo antes de usar em producao.
func EbfTrim(args ...any) (any, error) {
	return evaluateByCategory("ebfTrim", "unknown", true, args...)
}

// IsEqual equivale a isEqual. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func IsEqual(args ...any) (any, error) {
	return evaluateByCategory("isEqual", "operator", false, args...)
}

// IsGreater equivale a isGreater. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func IsGreater(args ...any) (any, error) {
	return evaluateByCategory("isGreater", "operator", false, args...)
}

// IsMinor equivale a isMinor. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func IsMinor(args ...any) (any, error) {
	return evaluateByCategory("isMinor", "operator", false, args...)
}

// IsMinorOrEqual equivale a isMinorOrEqual. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func IsMinorOrEqual(args ...any) (any, error) {
	return evaluateByCategory("isMinorOrEqual", "operator", false, args...)
}

// IsNullOrEmpty equivale a isNullOrEmpty. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func IsNullOrEmpty(args ...any) (any, error) {
	return evaluateByCategory("isNullOrEmpty", "operator", false, args...)
}

// L2sFlowRunWithMessage equivale a l2sFlowRunWithMessage. Criar adapter conectado ao runtime novo antes de usar em producao.
func L2sFlowRunWithMessage(args ...any) (any, error) {
	return evaluateByCategory("l2sFlowRunWithMessage", "unknown", true, args...)
}

// OprAdd equivale a oprAdd. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func OprAdd(args ...any) (any, error) {
	return evaluateByCategory("oprAdd", "operator", false, args...)
}

// OprAnd equivale a oprAnd. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func OprAnd(args ...any) (any, error) {
	return evaluateByCategory("oprAnd", "operator", false, args...)
}

// OprIf equivale a oprIf. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func OprIf(args ...any) (any, error) {
	return evaluateByCategory("oprIf", "operator", false, args...)
}

// OprNot equivale a oprNot. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func OprNot(args ...any) (any, error) {
	return evaluateByCategory("oprNot", "operator", false, args...)
}

// OprOr equivale a oprOr. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func OprOr(args ...any) (any, error) {
	return evaluateByCategory("oprOr", "operator", false, args...)
}

// OprSubtract equivale a oprSubtract. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func OprSubtract(args ...any) (any, error) {
	return evaluateByCategory("oprSubtract", "operator", false, args...)
}

// ToDouble equivale a toDouble. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func ToDouble(args ...any) (any, error) {
	return evaluateByCategory("toDouble", "conversion", false, args...)
}

// ToLong equivale a toLong. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func ToLong(args ...any) (any, error) {
	return evaluateByCategory("toLong", "conversion", false, args...)
}

// ToString equivale a toString. Equivalente inicial gerado por categoria; validar parametros reais do fluxo.
func ToString(args ...any) (any, error) {
	return evaluateByCategory("toString", "conversion", false, args...)
}

func evaluateByCategory(name, category string, adapterRequired bool, args ...any) (any, error) {
	if adapterRequired {
		return nil, fmt.Errorf("%s exige adapter de runtime antes da execucao", name)
	}
	switch strings.ToLower(category) {
	case "string":
		parts := make([]string, 0, len(args))
		for _, arg := range args {
			parts = append(parts, fmt.Sprint(arg))
		}
		return strings.Join(parts, ""), nil
	case "conversion":
		if len(args) == 0 {
			return nil, nil
		}
		if v, err := strconv.ParseFloat(fmt.Sprint(args[0]), 64); err == nil {
			return v, nil
		}
		return fmt.Sprint(args[0]), nil
	case "collection":
		return args, nil
	case "operator":
		if len(args) >= 2 {
			return fmt.Sprint(args[0]) == fmt.Sprint(args[1]), nil
		}
		return nil, errors.New("operador Maker precisa de parametros")
	default:
		return nil, fmt.Errorf("%s precisa de revisao manual para categoria %s", name, category)
	}
}
