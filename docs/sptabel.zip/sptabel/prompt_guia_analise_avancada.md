# Guia Avançado: Como uma IA deve analisar artefatos FRZ e gerar documentação + Mock fiel

Este documento ensina uma IA a executar uma análise técnica completa de módulos exportados do Maker 5/WebRun e a produzir dois entregáveis de alta qualidade:

1. **Documento de migração** com 8 seções (plano técnico responsável)
2. **Mock HTML navegável** fiel à interface real da tela

---

## PARTE 1 — Como analisar os artefatos

### 1.1 Ordem de leitura obrigatória

Leia os artefatos nesta sequência. Cada leitura deve construir sobre a anterior.

```
1. analysis_summary.json       → contexto numérico e lista de submodulos
2. function_coverage.json      → mapa de riscos por função
3. Markdown principal          → narrativa funcional profunda
4. function_equivalents_manifest.json  → adapter_required por função
5. analysis.sqlite             → apenas para consultas pontuais de relacionamento
```

Nunca inverta essa ordem. O JSON dá o mapa; o Markdown dá o território.

---

### 1.2 O que extrair do `analysis_summary.json`

Este arquivo é sua âncora quantitativa. Extraia:

- **Métricas brutas**: `TotalForms`, `TotalComponents`, `TotalEvents`, `TotalRules`, `TotalFlows`, `TotalQueries`, `TotalTables`, `TotalSubmodules`
- **Estimativa de porte**: `EstimatedFunctionPts`, `EstimatedLower`, `EstimatedUpper` — use como guia de complexidade, não como SLA
- **Submodulos detectados**: para cada submodulo, anote:
  - `Nome` — identificador técnico
  - `FormularioOrigem` — nome legível (ex: "Grid Espera")
  - `CampoVinculo` — chave de relacionamento
  - `CargaDinamica` — se true, a query não está no FRZ → risco médio
  - `EhSubformulario` — false = grid operacional sem vínculo claro → risco alto
  - Eventos do submodulo e `RequerMigracaoManual`
- **Funções desconhecidas** (`unknown_functions`): para cada uma, extraia:
  - `ProbableOrigin`: `legacy_wrapper` | `custom_project_function` | `third_party_library`
  - `Contexts`: em quais componentes/eventos é usada
  - `RuleNames`: quais regras de negócio dependem dela

**Regra**: toda função com `ProbableOrigin != "native"` é um ponto de bloqueio. Registre no mapa de riscos.

---

### 1.3 O que extrair do `function_coverage.json`

Este arquivo é seu mapa de risco por função. Para cada função:

- `status`: `cataloged` = conhecida; qualquer outra = risco
- `match.category`: classifica o tipo de função
  - `ui` = manipulação de DOM/componente → precisa de adapter de frontend
  - `flow` = execução assíncrona, chamadas entre formulários → adapter crítico
  - `database` = queries SQL diretas → migrar para repository
  - `integration` = REST, socket, certificado → nunca migrar sem credenciais
  - `security` = autenticação, sessão → tratar com cuidado especial
- `match.layer`: `client` = roda no browser (JS); `server` = roda no Java; duplo = wrapper client→server
- `match.adapter_required` (do manifest): se `true`, a função NÃO pode ser usada diretamente no novo sistema

**Regra de decisão por categoria**:

| Categoria | Estratégia de migração |
|---|---|
| `string`, `math`, `operator`, `conversion` | Implementar diretamente — trivial |
| `collection` | Implementar como slice/array em Go ou Array em TS |
| `database` | Migrar para Repository com query SQL explícita |
| `ui` | Adapter de frontend (React state/DOM API) |
| `flow` | Adapter assíncrono (goroutine + channel em Go, async/await em TS) |
| `grid` | Substituir por tabela com seleção/evento no frontend |
| `system` | Avaliar caso a caso (timer → SSE/WebSocket push) |
| `security` | JWT claims + middleware — nunca copiar lógica WebRun |
| `integration` | Bloquear até ter credenciais e endpoint confirmados |
| `unknown` | Bloquear até obter código-fonte ou especificação |

---

### 1.4 Como ler o Markdown principal — os 5 passos

O Markdown é denso. Leia em 5 passagens, cada uma com foco diferente.

#### Passagem 1 — Estrutura da tela (seções 1 a 3)
- Qual é a **tabela principal** e sua **query SQL**? → define a entidade central do backend
- Quais são os **campos detectados**? Se zero, o formulário é read-only ou usa view
- **Contagem por categoria** de componentes: `button` e `grid` são os mais importantes

#### Passagem 2 — Grids e subformulários (seção 3)
Para cada grid/submodulo:
- Qual é o **vínculo** com a tela pai? → traduz para filtro WHERE no endpoint filho
- Há eventos? Quais regras disparam? → traduz para ações no frontend

#### Passagem 3 — Eventos por componente (seção 5)
Para cada componente com evento:
- **Qual é o fluxo técnico** (bloco `text`)? → é a especificação da regra de negócio
- Quais funções são usadas? → cruzar com `function_coverage.json`
- Há `CALLRULE`? → dependência de regra global, fora do escopo deste FRZ → registrar como risco
- Há `ebfAsyncJavaFlowExecute`? → operação assíncrona → usar goroutine + websocket/SSE no novo sistema
- Há `ebfChannelExecuteRuleOnForm`? → comunicação entre formulários → traduzir para evento WebSocket para o frame pai

#### Passagem 4 — Queries (seção 6, se presente)
- Cada query deve virar um método de Repository
- Substituir `:FUNCAO_sessao_varIDOperador` por claim JWT `operador_id`
- Substituir `:FUNCAO_sessao_varIDEmpresa` por claim JWT `empresa_id`
- Nunca remover o filtro de `id_empresa` — é o isolamento multi-tenant

#### Passagem 5 — Funções desconhecidas no contexto dos fluxos
- Localize cada função desconhecida dentro dos fluxos técnicos onde ela aparece
- Entenda **o que vem antes e depois** dela no fluxo → permite inferir o contrato esperado
- Exemplo: se o fluxo faz `$resultado = funcaoDesconhecida(param)` e depois `if isNullOrEmpty($resultado)`, a função provavelmente retorna string nullable

---

### 1.5 Como usar o `function_equivalents_manifest.json`

- Funções com `adapter_required: false` → ponto de partida seguro; validar parâmetros reais
- Funções com `adapter_required: true` → criar adapter explícito antes de usar em produção
- O manifest não garante equivalência perfeita — é um rascunho inicial

**Nunca** usar uma função do manifest em produção sem:
1. Verificar os parâmetros reais no fluxo técnico do Markdown
2. Testar o comportamento esperado contra o sistema legado

---

### 1.6 Como identificar o que a tela realmente faz

Após ler os artefatos, construa uma **narrativa funcional** respondendo:

1. **Qual é o usuário desta tela?** (operador, supervisor, admin?)
2. **Qual é o objeto central?** (chamado, contato, condomínio?)
3. **Qual é o ciclo de vida do objeto?** (criar → atender → transferir → finalizar?)
4. **O que atualiza em tempo real?** (timer, websocket, polling?)
5. **Quais integrações externas existem?** (WhatsApp, API, webhook, N8N, IA?)
6. **Quais ações são destrutivas ou irreversíveis?** (finalizar, excluir, transferir?)

Responder essas 6 perguntas produz o **Resumo Executivo** (Seção 1 do documento de migração).

---

### 1.7 Como montar o Mapa de Riscos

Classifique cada item em 3 níveis:

**Alto** → bloqueia a migração até ser resolvido:
- Funções desconhecidas com `ProbableOrigin` = `custom_project_function` ou `third_party_library`
- Submodulos com `CargaDinamica=true` e sem `CampoVinculo`
- Qualquer integração externa sem credenciais confirmadas
- Regras com tipo `desconhecido` e `RequerMigracaoManual=true`
- Variáveis de sessão WebRun sem equivalente claro no novo sistema

**Médio** → não bloqueia, mas exige decisão antes de gerar código:
- Funções com `adapter_required=true`
- `CALLRULE` para regras fora do FRZ atual
- Queries com parâmetros de sessão WebRun (`:FUNCAO_sessao_*`)
- Fluxos com múltiplas chamadas assíncronas encadeadas (`ebfAsyncJavaFlowExecute`)

**Baixo** → pode ser implementado diretamente:
- Funções `string`, `math`, `operator`, `conversion`
- Grids com vínculo claro e sem eventos complexos
- Botões que apenas abrem outro formulário (`ebfFormOpenForm`, `ebfFormOpenFilteredForm`)
- Leitura de variáveis de sessão simples

---

## PARTE 2 — Como produzir o documento de migração (8 seções)

### Estrutura obrigatória

```
1. Resumo executivo
2. Leitura funcional da tela e subformulários
3. Mapa de riscos (por funções, regras, integrações, dados)
4. Estratégia de arquitetura alvo
5. Plano de fases
6. Perguntas ao cliente
7. Backlog técnico priorizado
8. Pontos que exigem revisão humana
```

### Regras de escrita

**Seção 1 — Resumo executivo**
- Escreva para não-técnicos: qual é a tela, quem usa, qual o risco geral
- Mencione os números do `analysis_summary.json` mas contextualize-os
- Termine com a recomendação de abordagem (migração incremental vs. reescrita total)

**Seção 2 — Leitura funcional**
- Organize por áreas funcionais, não por componente
- Para cada subformulário: o que ele mostra, quando carrega, o que acontece ao interagir
- Para cada grupo de botões: o fluxo de negócio que eles implementam em conjunto

**Seção 3 — Mapa de riscos**
- Use tabelas com colunas: Item | Risco | Motivo
- Agrupe por: funções desconhecidas, regras/fluxos, dados/integrações, variáveis de sessão
- Para funções desconhecidas: inclua o contexto de uso (em qual fluxo aparece)

**Seção 4 — Arquitetura alvo**
- Backend Go: sempre `Handler → Service → Repository`
- Frontend TypeScript com React
- JWT com claims de empresa e operador
- `empresa_id` obrigatório em toda query — nunca opcional
- WebSocket nativo para substituir Timer + Socket.io
- Listar contratos de API como tabela de endpoints

**Seção 5 — Plano de fases**
- 5 fases: Descoberta → PoC → Migração Incremental → Homologação → Produção
- Fase de Migração Incremental deve listar itens em ordem de menor para maior risco
- Nunca começar por integrações externas ou funções desconhecidas

**Seção 6 — Perguntas ao cliente**
- Cada pergunta deve ser rastreável a um artefato (nome da função desconhecida, nome do subformulário, etc.)
- Agrupe por tema: funções desconhecidas, integrações, regras de negócio, permissões
- Formule perguntas fechadas quando possível (sim/não + detalhe)

**Seção 7 — Backlog técnico**
- Organize em prioridades: P0 (bloqueadores) → P1 (core) → P2 (secundário) → P3 (integrações) → P4 (supervisão)
- Cada item deve ter: descrição, pontos de complexidade (1–5), referência ao artefato
- Pontos: 1=trivial (< 2h), 2=simples (meio dia), 3=médio (1 dia), 4=complexo (2-3 dias), 5=muito complexo (> 3 dias)

**Seção 8 — Revisão humana**
- Use tabela com colunas: # | Ponto | Justificativa | Responsável
- Responsável pode ser: Dev, Dev sênior, Ops, Cliente, Analista, Fornecedor

---

## PARTE 3 — Como gerar o Mock HTML fiel

### 3.1 Princípio fundamental

**O mock não é um protótipo de componentes — é uma simulação da sessão de trabalho real do usuário.**

O objetivo é que, ao abrir o arquivo, o cliente reconheça a tela e consiga validar fluxos antes de qualquer código ser escrito.

---

### 3.2 Como inferir o layout da tela a partir dos artefatos

Sem screenshot ou especificação visual, use esta heurística:

#### Identificar o tipo de tela

| Padrão nos componentes | Tipo de interface |
|---|---|
| Muitos `button` + `component` + `html_runtime` + `timer` | Painel operacional / dashboard |
| `grid` principal com muitos campos + `lookup` | CRUD de cadastro |
| `container` dominante + `html_runtime` | Tela com HTML customizado embutido |
| `upload` + `textarea` + botões de envio | Interface de comunicação/chat |
| Presença de `gridFilaDeEspera`, `gridEmAtendimento`, `gridPotenciais` | Painel de atendimento multicanal |

#### Inferir layout de colunas

- Se há **múltiplos grids** de fila → sidebar esquerda com abas
- Se há **chat** (botão enviar + textarea + botão gravar + upload) → coluna central dominante
- Se há **dados do contato** + **métricas** → painel direito colapsável
- Se há **múltiplas abas** na regra de transferência → sistema de tabs na área central

#### Inferir abas do formulário a partir das regras

As regras revelam a estrutura de abas. Procure padrões como:
- `ebfFormOpenTab(Transferência)` → existe aba "Transferência"
- `ebfFormOpenTab(Atendimento)` → existe aba "Atendimento"
- `ebfFrameOpenForm` / `ebfFrameCloseForm` → existe área de frame/iframe

---

### 3.3 Como mapear componentes para elementos HTML

| Componente do FRZ | Elemento HTML sugerido |
|---|---|
| `button` com nome começando em `bot` ou `Btn` | `<button>` com ícone FontAwesome |
| `grid` / submodulo com eventos de clique | `<div class="queue-item">` clicável na sidebar |
| `grid` com duplo clique | Tabela interativa com evento `dblclick` |
| `textarea` (`txtMensagem`) | `<textarea>` com auto-resize e envio por Enter |
| `upload` (componente tipo `E`) | Botão de paperclip + prévia de arquivo |
| `html_runtime` | `<div>` com innerHTML customizado |
| `timer` | Intervalo JS (`setInterval`) com push visual |
| `lookup` | `<select>` com opções mockadas |
| `component` com prefixo `lbl` | `<span>` ou `<div>` com dado exibido |
| `container` com prefixo `cont_` | `<div>` com classe de container colapsável |

---

### 3.4 Como traduzir fluxos técnicos em comportamento interativo

Para cada fluxo importante, implemente uma versão simplificada em JavaScript:

**Padrão "toggle de classe CSS"** (muito comum no WebRun):
```
IF ebfSearchSubstring($classe, open)
  THEN ebfHtmlSetAttribute($elem, class, remove 'open')
  ELSE ebfHtmlSetAttribute($elem, class, add 'open')
```
→ Traduz para: `element.classList.toggle('open')`

**Padrão "validar antes de agir"**:
```
IF isNullOrEmpty($idChamado)
  THEN END
  ELSE [ação principal]
```
→ Traduz para: `if (!selectedId) return;` antes da ação

**Padrão "abrir formulário filtrado"** (`ebfFormOpenFilteredForm`):
→ Traduz para: abrir um modal ou nova aba com dados filtrados
→ No mock: `alert('Abrindo formulário X com filtro Y')`

**Padrão "executar assíncrono"** (`ebfAsyncJavaFlowExecute`):
→ Traduz para: chamada fetch/WebSocket com feedback visual (loading state)
→ No mock: `showToast('Processando...')` + simulação de resultado

**Padrão "comunicar com formulário pai"** (`ebfChannelExecuteRuleOnForm`):
→ Traduz para: evento WebSocket do servidor → atualização no frame pai
→ No mock: `window.parent.postMessage(...)` ou simulação com toast

---

### 3.5 Padrões obrigatórios de UX no Mock

**Tema e visual**
- Usar variáveis CSS (`--bg`, `--surface`, `--primary`, `--border`, `--text`, `--muted`)
- Tema escuro para painéis operacionais (reduz fadiga visual em uso contínuo)
- Tema claro para formulários de cadastro
- Sempre usar `box-sizing: border-box` e reset mínimo

**Feedback visual**
- Toda ação do usuário deve ter resposta visual imediata
- Implementar função `showToast(mensagem, tipo)` para feedback de ações
- Estados de hover em todos os elementos clicáveis (`transition: background .15s`)
- Botão ativo/selecionado deve ter visual distinto do inativo

**Dados mockados realistas**
- Não usar "Lorem ipsum" — usar dados do domínio real (nomes de condomínio, tipos de chamado)
- IDs de chamado com números plausíveis (ex: #7842, não #1)
- Horários coerentes com um dia de trabalho (09:01, 09:08, não 00:00)
- Status e tags usando as mesmas nomenclaturas dos fluxos do FRZ

**Interatividade mínima obrigatória**
- Selecionar item em grid deve carregar dados na área de detalhe
- Formulário de envio deve adicionar item visível ao submeter
- Botões de finalizar/transferir devem ter confirmação (`confirm()`)
- Timer de chamado deve funcionar em tempo real

**Acessibilidade básica**
- `data-tip` em todos os botões sem label visível (tooltips)
- Contraste de texto: mínimo 4.5:1 para texto normal
- Foco visível em elementos interativos

---

### 3.6 Estrutura do arquivo HTML do Mock

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <!-- Charset, viewport, título, FontAwesome CDN -->
  <!-- CSS: variáveis → reset → topbar → sidebar → chat → input → painel direito → animações -->
</head>
<body>
  <!-- 1. TOPBAR: logo, navegação, info do operador, ações globais -->
  <header class="topbar">...</header>
  
  <!-- 2. WORKSPACE: flex-row, ocupa o restante da altura -->
  <div class="workspace">
    
    <!-- 3. SIDEBAR: filas de atendimento com abas -->
    <aside class="sidebar">
      <div class="sidebar-search">...</div>
      <div class="sidebar-tabs">...</div>
      <div class="queue-list" id="q-[nome]">...</div>
    </aside>
    
    <!-- 4. ÁREA CENTRAL: chat + tabs + input -->
    <main class="chat-area">
      <!-- Estado vazio -->
      <div class="chat-placeholder" id="chatPlaceholder">...</div>
      <!-- Estado ativo (oculto por padrão) -->
      <div id="chatActive" style="display:none">
        <div class="chat-header">...</div>
        <div class="chat-tabs">...</div>
        <!-- Panes por aba -->
        <div id="paneAtendimento">
          <div class="messages">...</div>
          <div class="input-area">...</div>
        </div>
        <div id="paneTransferencia" style="display:none">...</div>
        <div id="paneHistorico" style="display:none">...</div>
      </div>
    </main>
    
    <!-- 5. PAINEL DIREITO: info do contato, métricas, ações -->
    <aside class="right-panel">...</aside>
    
  </div>
  
  <!-- 6. SCRIPT: switchQueue, openChat, openTab, sendMessage, showToast, timer -->
  <script>...</script>
</body>
</html>
```

---

### 3.7 Como popular o Mock com dados reais dos artefatos

**Grids / filas laterais**: Use os nomes dos submodulos detectados como abas da sidebar.
- `gridPotenciais` → aba "Potenciais"
- `gridFilaDeEspera` → aba "Espera"
- `gridEmAtendimento` → aba "Andamento"

**Botões de ação**: Mapeie cada `button` do FRZ para um botão na interface.
- Prefixos `botFinalizar*` → botão "Finalizar" com variante "Sem protocolo"
- Prefixos `botTransferir*` → botão "Transferir" que abre aba de transferência
- `botGravar` → botão de microfone com toggle de gravação
- `botAnexar` → botão de paperclip
- `botEnviar` → botão de enviar mensagem
- `botHistoricoChat` → ícone de IA/histórico
- `BtnTimer` → não vira botão visível; vira `setInterval` no JavaScript

**Abas**: Extraia dos fluxos de `ebfFormOpenTab`:
- Cada valor passado como parâmetro é o nome de uma aba

**Métricas do operador**: Use os campos da query principal:
- `concluidos`, `pendentes`, `agendados`, `media` → cards de métricas

**Campos de informação do contato**: Inferir a partir dos parâmetros passados entre regras:
- `{IDDOCHAMADO}` → ID do chamado ativo
- `{lblNome}` → nome do contato
- `{Sessao}` → sessão WhatsApp
- `{TemplateReabertura}` → template de reabertura da janela

---

### 3.8 Checklist antes de entregar o Mock

- [ ] Abrir o arquivo no browser sem erros no console
- [ ] Selecionar um item de cada fila → chat deve abrir corretamente
- [ ] Digitar mensagem e pressionar Enter → mensagem aparece no chat
- [ ] Botão Finalizar → pede confirmação → fecha o atendimento
- [ ] Botão Transferir → abre aba de transferência com formulário
- [ ] Aba Histórico → mostra tabela de transferências passadas
- [ ] Timer no painel direito → incrementa a cada segundo
- [ ] Botão de microfone → muda visual ao clicar (toggle recording)
- [ ] Clicar em telefone/CPF/protocolo → toast de "copiado"
- [ ] Layout responsivo básico → não quebra em 1200px de largura

---

## PARTE 4 — Resumo executivo para a IA

Quando receber um conjunto de artefatos FRZ para analisar, siga este processo em 4 etapas:

### Etapa 1 — Orientação (5 minutos de leitura)
Leia `analysis_summary.json` e `function_coverage.json` integralmente antes de qualquer outra coisa.
Responda mentalmente: _"Qual é o porte? Quais são os riscos críticos? Há funções que bloqueiam a migração?"_

### Etapa 2 — Imersão funcional
Leia o Markdown principal com as 5 passagens descritas na Seção 1.4.
Construa uma narrativa funcional respondendo as 6 perguntas da Seção 1.6.

### Etapa 3 — Produção do documento
Escreva as 8 seções na ordem definida. Nunca pule seções.
A Seção 6 (perguntas) e a Seção 8 (revisão humana) são as mais valiosas — não as economize.

### Etapa 4 — Mock HTML
Infira o layout usando a heurística da Seção 3.2.
Implemente o mock com todos os componentes detectados no FRZ, dados realistas e JavaScript funcional.
Valide com o checklist da Seção 3.8.

---

## Apêndice — Anti-padrões a evitar

| Anti-padrão | Por quê é errado | Correto |
|---|---|---|
| Gerar código de produção antes da Fase 3 | Funções desconhecidas e regras ambíguas causam retrabalho | Primeiro o plano, depois o código |
| Usar `USE database` para trocar de tenant | Viola isolamento multi-tenant | Pool por banco via `empresa_id` |
| Converter `ebfFormOpenFilteredForm` em redirect | Essa função abre um modal filtrado, não uma página nova | Modal com query string de filtro |
| Tratar variáveis de sessão WebRun como globais | Elas são por usuário/request, não por aplicação | JWT claims ou request context |
| Mock sem interatividade JavaScript | Não permite validação de fluxo pelo cliente | Pelo menos: seleção de item, envio de mensagem, toast de ações |
| Mock com dados genéricos ("Item 1", "Usuário X") | Não provoca reconhecimento do cliente | Usar domínio real: nomes de condomínio, tipos de chamado |
| Implementar `ebfChannelExecuteRuleOnForm` como chamada REST | Essa função envia evento ao frame pai, não ao servidor | WebSocket evento → frame pai |
| Assumir que `unknown` = não existe | Função pode existir como lib embutida no projeto | Sempre perguntar ao cliente antes de descartar |
