export type MakerFunctionMeta = {
  name: string;
  category: string;
  layer: string;
  status: string;
  adapterRequired: boolean;
  description: string;
};

export type MakerRuntimeAdapters = Record<string, (...args: unknown[]) => unknown | Promise<unknown>>;

export const functionCatalog: Record<string, MakerFunctionMeta> = {
  "ebfappend": { name: "ebfAppend", category: "collection", layer: "client", status: "cataloged", adapterRequired: false, description: "Junta vários itens de texto em apenas um item." },
  "ebfchangecomponentvalueotherform": { name: "ebfChangeComponentValueOtherForm", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Altera o valor de um componente que esteja em outro formulário que não o corrente." },
  "ebfcloseform": { name: "ebfCloseForm", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Essa função é utilizada para fechar o formulário que chama o fluxo." },
  "ebfconcat": { name: "ebfConcat", category: "string", layer: "client", status: "cataloged", adapterRequired: false, description: "Junta vários itens de texto em apenas um item." },
  "ebfformatdatetime": { name: "ebfFormatDateTime", category: "date", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função modifica a formatação da data passada no primeiro parâmetro para a formatação passada no segundo parâmetro." },
  "ebfformchangecomponentvalue": { name: "ebfFormChangeComponentValue", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "A função altera o conteúdo do componente que está no formulário passado como parâmetro pelo conteúdo passado no 3º parâmetro." },
  "ebfformgetcomponentvalue": { name: "ebfFormGetComponentValue", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Obtém o conteúdo do componente passado no segundo parâmetro e o retorna." },
  "ebfformgetlookupname": { name: "ebfFormGetLookupName", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Função que obtém o valor exibido na lista dinâmica." },
  "ebfformopenfilteredform": { name: "ebfFormOpenFilteredForm", category: "ui", layer: "server", status: "cataloged", adapterRequired: true, description: "Form Open Filtered Form" },
  "ebfformopenform": { name: "ebfFormOpenForm", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Abre o formulário passado por parâmetro." },
  "ebfformrefreshcomponent": { name: "ebfFormRefreshComponent", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Atualiza o conteúdo do componente passado por parâmetro." },
  "ebfformsetenabled": { name: "ebfFormSetEnabled", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Esta função habilita o componente se a condição passada no segundo parâmetro for verdadeira, ou desabilita caso a condição seja falsa. Se o componente estiver desabilitado, não será possível modificar seu conteúdo." },
  "ebfformsetfocus": { name: "ebfFormSetFocus", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Essa função é utilizada para focar um determinado componente passado como parâmetro." },
  "ebfformsetlookupname": { name: "ebfFormSetLookupName", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Função que altera o valor exibido na lista dinâmica." },
  "ebfformsetvisible": { name: "ebfFormSetVisible", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Esta função mostra o componente se a condição passada no segundo parâmetro for verdadeira ou oculta caso a condição seja falsa." },
  "ebfgetcomponentvaluefromotherform": { name: "ebfGetComponentValueFromOtherForm", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Nao detectado - revisao manual recomendada" },
  "ebfgetelementfromlist": { name: "ebfGetElementFromList", category: "collection", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função busca e retorna o elemento que deseja obter, a partir da sua posição na lista." },
  "ebfgetformresultset": { name: "ebfGetFormResultset", category: "ui", layer: "server", status: "cataloged", adapterRequired: true, description: "Get Form Resultset" },
  "ebfgetsessionattribute": { name: "ebfGetSessionAttribute", category: "math", layer: "client", status: "cataloged", adapterRequired: false, description: "Obtém o conteúdo da variável criada pela função \"Definir variável de sessão\" passando no 1º parâmetro o nome da variável e no 2º parâmetro o valor lógico verdadeiro ou falso, indicando se é ou não uma variável global. Para variáveis" },
  "ebfgetusercode": { name: "ebfGetUserCode", category: "system", layer: "server", status: "cataloged", adapterRequired: true, description: "Get User Code" },
  "ebfgridgetvalue": { name: "ebfGridGetValue", category: "grid", layer: "client", status: "cataloged", adapterRequired: true, description: "Essa função retorna o valor que está na Grade, a partir da informação da linha (a primeira linha da Grade é a linha \"0\" (zero)) e a coluna que deseja obter o valor." },
  "ebfgroupboxshowcomponents": { name: "ebfGroupBoxShowComponents", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Esta função mostra ou oculta o componente moldura e todos os componentes que estiverem \"dentro\" da área do mesmo." },
  "ebfhtmlremovechild": { name: "ebfHtmlRemoveChild", category: "unknown", layer: "client", status: "cataloged", adapterRequired: true, description: "Esta função remove o filho de um elemento especificado por parâmetro." },
  "ebfindexof": { name: "ebfIndexOf", category: "unknown", layer: "client", status: "cataloged", adapterRequired: true, description: "Esta função localiza o conteúdo do 2° parâmetro dentro do conteúdo do primeiro parâmetro." },
  "ebflength": { name: "ebfLength", category: "unknown", layer: "client", status: "cataloged", adapterRequired: true, description: "A função recebe um texto e retorna o tamanho do mesmo." },
  "ebflistlength": { name: "ebfListLength", category: "collection", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função retorna o tamanho da lista, ou seja, a quantidade de elementos que pertencem à lista." },
  "ebflistparamscreate": { name: "ebfListParamsCreate", category: "collection", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função cria uma lista com todos os valores que foram passados pelos parâmetros." },
  "ebfnewline": { name: "ebfNewLine", category: "unknown", layer: "client", status: "cataloged", adapterRequired: true, description: "Usado para quebrar a linha (pular linha) em um texto, onde o parâmetro recebido será a quantidade de linhas à serem puladas." },
  "ebfrefreshcomponentotherform": { name: "ebfRefreshComponentOtherForm", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Atualiza o componente em outro formulário." },
  "ebfremovesessionattribute": { name: "ebfRemoveSessionAttribute", category: "math", layer: "client", status: "cataloged", adapterRequired: false, description: "Remove a variável de sessão passando no 1º parâmetro o nome da variável e no 2º o valor Lógico que indica se ela é ou não global." },
  "ebfreplace": { name: "ebfReplace", category: "string", layer: "client", status: "cataloged", adapterRequired: false, description: "A função localiza o 2º parâmetro dentro do texto e o substitui pelo conteúdo passado no 3º parâmetro." },
  "ebfreplaceall": { name: "ebfReplaceAll", category: "string", layer: "client", status: "cataloged", adapterRequired: false, description: "Esta função localiza todas as subsequências iguais ao 2º parâmetro dentro do texto e os substituem pelo conteúdo passado no 3º parâmetro." },
  "ebfresultsetabsolute": { name: "ebfResultSetAbsolute", category: "system", layer: "server", status: "cataloged", adapterRequired: true, description: "Result Set Absolute" },
  "ebfrichtextinserttextatposition": { name: "ebfRichTextInsertTextAtPosition", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "Insere um texto na posição do cursor em um Texto Rico." },
  "ebfsearchsubstring": { name: "ebfSearchSubstring", category: "string", layer: "client", status: "cataloged", adapterRequired: false, description: "Esta função procura dentro do 1° parâmetro a subsequência passada no 2º parâmetro." },
  "ebfsetsessionattribute": { name: "ebfSetSessionAttribute", category: "ui", layer: "client", status: "cataloged", adapterRequired: true, description: "As variáveis de sessão são utilizadas quando houver a necessidade de ter uma variável que se mantém para regras diferentes. Variáveis de sessão não globais se mantém de acordo com o usuário e as globais se mantém para todo usuário." },
  "ebfsqlclose": { name: "ebfSQLClose", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L Close" },
  "ebfsqlcommittransaction": { name: "ebfSQLCommitTransaction", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L Commit Transaction" },
  "ebfsqleof": { name: "ebfSQLEOF", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L E O F" },
  "ebfsqlexecutequery": { name: "ebfSQLExecuteQuery", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L Execute Query" },
  "ebfsqlexecuteupdate": { name: "ebfSQLExecuteUpdate", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L Execute Update" },
  "ebfsqlfield": { name: "ebfSQLField", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L Field" },
  "ebfsqlgetfieldfromform": { name: "ebfSQLGetFieldFromForm", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Obtém o conteúdo de um componente do formulário principal ou de qualquer outro passado por parâmetro." },
  "ebfsqlnext": { name: "ebfSQLNext", category: "database", layer: "server", status: "cataloged", adapterRequired: true, description: "S Q L Next" },
  "ebfstopruleexecution": { name: "ebfStopRuleExecution", category: "flow", layer: "client", status: "cataloged", adapterRequired: true, description: "Interrompe a execução do fluxo. Caso seja passado alguma mensagem por parâmetro, esta é exibida. Se houver algum processamento após a utilização dessa função, este não será executado." },
  "ebfsubstring": { name: "ebfSubstring", category: "string", layer: "client", status: "cataloged", adapterRequired: false, description: "A função recebe um texto (1º parâmetro) e retorna uma subsequência deste texto. A subsequência inicia na posição indicada no 2º parâmetro, com o tamanho indicado no 3º parâmetro." },
  "ebfsubstringinverse": { name: "ebfSubstringInverse", category: "string", layer: "client", status: "cataloged", adapterRequired: false, description: "A função recebe um texto (primeiro parâmetro) e retorna apenas a quantidade de caracteres passada no segundo" },
  "ebftrim": { name: "ebfTrim", category: "unknown", layer: "client", status: "cataloged", adapterRequired: true, description: "Remove os espaços existentes antes e depois do texto passado por parâmetro e retorna." },
  "isequal": { name: "isEqual", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se os valores passados por parâmetro são iguais, ou seja, possuem o mesmo valor." },
  "isgreater": { name: "isGreater", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se o valor do 1º parâmetro é maior que o do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso. Se os valores dos parâmetros forem iguais o retorno será falso, pois o mesmo valor não é maior que ele mesmo." },
  "isminor": { name: "isMinor", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se o valor do 1º parâmetro é menor que o valor do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso. Se os valores dos parâmetros forem iguais o retorno será falso, pois o mesmo valor não é menor que ele mesmo." },
  "isminororequal": { name: "isMinorOrEqual", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se o valor do 1º parâmetro é menor ou igual ao valor do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso." },
  "isnullorempty": { name: "isNullOrEmpty", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se o parâmetro é nulo ou vazio. A depender do resultado, retorna verdadeiro ou falso." },
  "l2sflowrunwithmessage": { name: "l2sFlowRunWithMessage", category: "unknown", layer: "unknown", status: "unknown", adapterRequired: true, description: "Nao detectado - revisao manual recomendada." },
  "opradd": { name: "oprAdd", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Retorna a soma dos números passados por parâmetros." },
  "oprand": { name: "oprAnd", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se algum valor passado é Falso, para retornar falso ou se são verdadeiros para retornar verdadeiro." },
  "oprif": { name: "oprIf", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica o valor lógico do 1º parâmetro, se o mesmo for verdadeiro o retorno será o valor que estiver no 2º" },
  "oprnot": { name: "oprNot", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função inverte o valor lógico. Se o valor do parâmetro for verdadeiro o retorno dele terá o valor lógico falso. Caso contrário será verdadeiro." },
  "opror": { name: "oprOr", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Essa função verifica se algum valor passado por parâmetro é verdadeiro, para retornar verdadeiro ou se todos os parâmetros são valores falsos, para retornar falso." },
  "oprsubtract": { name: "oprSubtract", category: "operator", layer: "client", status: "cataloged", adapterRequired: false, description: "Subtração de valores informados nos parâmetros." },
  "todouble": { name: "toDouble", category: "conversion", layer: "client", status: "cataloged", adapterRequired: false, description: "Converte para fracionado o valor passado por parâmetro." },
  "tolong": { name: "toLong", category: "conversion", layer: "client", status: "cataloged", adapterRequired: false, description: "Converte um valor passado por parâmetro para Inteiro." },
  "tostring": { name: "toString", category: "conversion", layer: "client", status: "cataloged", adapterRequired: false, description: "Converte um valor passado por parâmetro para letras." },
};

export async function callMakerEquivalent(name: string, args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): Promise<unknown> {
  switch (name.trim().toLowerCase()) {
    case "ebfappend":
      return ebfAppend(args, adapters);
    case "ebfchangecomponentvalueotherform":
      return ebfChangeComponentValueOtherForm(args, adapters);
    case "ebfcloseform":
      return ebfCloseForm(args, adapters);
    case "ebfconcat":
      return ebfConcat(args, adapters);
    case "ebfformatdatetime":
      return ebfFormatDateTime(args, adapters);
    case "ebfformchangecomponentvalue":
      return ebfFormChangeComponentValue(args, adapters);
    case "ebfformgetcomponentvalue":
      return ebfFormGetComponentValue(args, adapters);
    case "ebfformgetlookupname":
      return ebfFormGetLookupName(args, adapters);
    case "ebfformopenfilteredform":
      return ebfFormOpenFilteredForm(args, adapters);
    case "ebfformopenform":
      return ebfFormOpenForm(args, adapters);
    case "ebfformrefreshcomponent":
      return ebfFormRefreshComponent(args, adapters);
    case "ebfformsetenabled":
      return ebfFormSetEnabled(args, adapters);
    case "ebfformsetfocus":
      return ebfFormSetFocus(args, adapters);
    case "ebfformsetlookupname":
      return ebfFormSetLookupName(args, adapters);
    case "ebfformsetvisible":
      return ebfFormSetVisible(args, adapters);
    case "ebfgetcomponentvaluefromotherform":
      return ebfGetComponentValueFromOtherForm(args, adapters);
    case "ebfgetelementfromlist":
      return ebfGetElementFromList(args, adapters);
    case "ebfgetformresultset":
      return ebfGetFormResultset(args, adapters);
    case "ebfgetsessionattribute":
      return ebfGetSessionAttribute(args, adapters);
    case "ebfgetusercode":
      return ebfGetUserCode(args, adapters);
    case "ebfgridgetvalue":
      return ebfGridGetValue(args, adapters);
    case "ebfgroupboxshowcomponents":
      return ebfGroupBoxShowComponents(args, adapters);
    case "ebfhtmlremovechild":
      return ebfHtmlRemoveChild(args, adapters);
    case "ebfindexof":
      return ebfIndexOf(args, adapters);
    case "ebflength":
      return ebfLength(args, adapters);
    case "ebflistlength":
      return ebfListLength(args, adapters);
    case "ebflistparamscreate":
      return ebfListParamsCreate(args, adapters);
    case "ebfnewline":
      return ebfNewLine(args, adapters);
    case "ebfrefreshcomponentotherform":
      return ebfRefreshComponentOtherForm(args, adapters);
    case "ebfremovesessionattribute":
      return ebfRemoveSessionAttribute(args, adapters);
    case "ebfreplace":
      return ebfReplace(args, adapters);
    case "ebfreplaceall":
      return ebfReplaceAll(args, adapters);
    case "ebfresultsetabsolute":
      return ebfResultSetAbsolute(args, adapters);
    case "ebfrichtextinserttextatposition":
      return ebfRichTextInsertTextAtPosition(args, adapters);
    case "ebfsearchsubstring":
      return ebfSearchSubstring(args, adapters);
    case "ebfsetsessionattribute":
      return ebfSetSessionAttribute(args, adapters);
    case "ebfsqlclose":
      return ebfSQLClose(args, adapters);
    case "ebfsqlcommittransaction":
      return ebfSQLCommitTransaction(args, adapters);
    case "ebfsqleof":
      return ebfSQLEOF(args, adapters);
    case "ebfsqlexecutequery":
      return ebfSQLExecuteQuery(args, adapters);
    case "ebfsqlexecuteupdate":
      return ebfSQLExecuteUpdate(args, adapters);
    case "ebfsqlfield":
      return ebfSQLField(args, adapters);
    case "ebfsqlgetfieldfromform":
      return ebfSQLGetFieldFromForm(args, adapters);
    case "ebfsqlnext":
      return ebfSQLNext(args, adapters);
    case "ebfstopruleexecution":
      return ebfStopRuleExecution(args, adapters);
    case "ebfsubstring":
      return ebfSubstring(args, adapters);
    case "ebfsubstringinverse":
      return ebfSubstringInverse(args, adapters);
    case "ebftrim":
      return ebfTrim(args, adapters);
    case "isequal":
      return isEqual(args, adapters);
    case "isgreater":
      return isGreater(args, adapters);
    case "isminor":
      return isMinor(args, adapters);
    case "isminororequal":
      return isMinorOrEqual(args, adapters);
    case "isnullorempty":
      return isNullOrEmpty(args, adapters);
    case "l2sflowrunwithmessage":
      return l2sFlowRunWithMessage(args, adapters);
    case "opradd":
      return oprAdd(args, adapters);
    case "oprand":
      return oprAnd(args, adapters);
    case "oprif":
      return oprIf(args, adapters);
    case "oprnot":
      return oprNot(args, adapters);
    case "opror":
      return oprOr(args, adapters);
    case "oprsubtract":
      return oprSubtract(args, adapters);
    case "todouble":
      return toDouble(args, adapters);
    case "tolong":
      return toLong(args, adapters);
    case "tostring":
      return toString(args, adapters);
    default:
      throw new Error(`Funcao Maker nao catalogada: ${name}`);
  }
}

export function ebfAppend(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfAppend", "collection", false, args, adapters);
}

export function ebfChangeComponentValueOtherForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfChangeComponentValueOtherForm", "ui", true, args, adapters);
}

export function ebfCloseForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfCloseForm", "flow", true, args, adapters);
}

export function ebfConcat(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfConcat", "string", false, args, adapters);
}

export function ebfFormatDateTime(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormatDateTime", "date", false, args, adapters);
}

export function ebfFormChangeComponentValue(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormChangeComponentValue", "flow", true, args, adapters);
}

export function ebfFormGetComponentValue(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormGetComponentValue", "flow", true, args, adapters);
}

export function ebfFormGetLookupName(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormGetLookupName", "ui", true, args, adapters);
}

export function ebfFormOpenFilteredForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormOpenFilteredForm", "ui", true, args, adapters);
}

export function ebfFormOpenForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormOpenForm", "ui", true, args, adapters);
}

export function ebfFormRefreshComponent(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormRefreshComponent", "flow", true, args, adapters);
}

export function ebfFormSetEnabled(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormSetEnabled", "flow", true, args, adapters);
}

export function ebfFormSetFocus(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormSetFocus", "flow", true, args, adapters);
}

export function ebfFormSetLookupName(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormSetLookupName", "ui", true, args, adapters);
}

export function ebfFormSetVisible(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfFormSetVisible", "flow", true, args, adapters);
}

export function ebfGetComponentValueFromOtherForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGetComponentValueFromOtherForm", "ui", true, args, adapters);
}

export function ebfGetElementFromList(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGetElementFromList", "collection", false, args, adapters);
}

export function ebfGetFormResultset(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGetFormResultset", "ui", true, args, adapters);
}

export function ebfGetSessionAttribute(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGetSessionAttribute", "math", false, args, adapters);
}

export function ebfGetUserCode(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGetUserCode", "system", true, args, adapters);
}

export function ebfGridGetValue(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGridGetValue", "grid", true, args, adapters);
}

export function ebfGroupBoxShowComponents(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfGroupBoxShowComponents", "ui", true, args, adapters);
}

export function ebfHtmlRemoveChild(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfHtmlRemoveChild", "unknown", true, args, adapters);
}

export function ebfIndexOf(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfIndexOf", "unknown", true, args, adapters);
}

export function ebfLength(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfLength", "unknown", true, args, adapters);
}

export function ebfListLength(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfListLength", "collection", false, args, adapters);
}

export function ebfListParamsCreate(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfListParamsCreate", "collection", false, args, adapters);
}

export function ebfNewLine(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfNewLine", "unknown", true, args, adapters);
}

export function ebfRefreshComponentOtherForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfRefreshComponentOtherForm", "ui", true, args, adapters);
}

export function ebfRemoveSessionAttribute(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfRemoveSessionAttribute", "math", false, args, adapters);
}

export function ebfReplace(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfReplace", "string", false, args, adapters);
}

export function ebfReplaceAll(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfReplaceAll", "string", false, args, adapters);
}

export function ebfResultSetAbsolute(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfResultSetAbsolute", "system", true, args, adapters);
}

export function ebfRichTextInsertTextAtPosition(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfRichTextInsertTextAtPosition", "ui", true, args, adapters);
}

export function ebfSearchSubstring(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSearchSubstring", "string", false, args, adapters);
}

export function ebfSetSessionAttribute(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSetSessionAttribute", "ui", true, args, adapters);
}

export function ebfSQLClose(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLClose", "database", true, args, adapters);
}

export function ebfSQLCommitTransaction(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLCommitTransaction", "database", true, args, adapters);
}

export function ebfSQLEOF(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLEOF", "database", true, args, adapters);
}

export function ebfSQLExecuteQuery(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLExecuteQuery", "database", true, args, adapters);
}

export function ebfSQLExecuteUpdate(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLExecuteUpdate", "database", true, args, adapters);
}

export function ebfSQLField(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLField", "database", true, args, adapters);
}

export function ebfSQLGetFieldFromForm(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLGetFieldFromForm", "flow", true, args, adapters);
}

export function ebfSQLNext(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSQLNext", "database", true, args, adapters);
}

export function ebfStopRuleExecution(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfStopRuleExecution", "flow", true, args, adapters);
}

export function ebfSubstring(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSubstring", "string", false, args, adapters);
}

export function ebfSubstringInverse(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfSubstringInverse", "string", false, args, adapters);
}

export function ebfTrim(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("ebfTrim", "unknown", true, args, adapters);
}

export function isEqual(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("isEqual", "operator", false, args, adapters);
}

export function isGreater(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("isGreater", "operator", false, args, adapters);
}

export function isMinor(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("isMinor", "operator", false, args, adapters);
}

export function isMinorOrEqual(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("isMinorOrEqual", "operator", false, args, adapters);
}

export function isNullOrEmpty(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("isNullOrEmpty", "operator", false, args, adapters);
}

export function l2sFlowRunWithMessage(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("l2sFlowRunWithMessage", "unknown", true, args, adapters);
}

export function oprAdd(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("oprAdd", "operator", false, args, adapters);
}

export function oprAnd(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("oprAnd", "operator", false, args, adapters);
}

export function oprIf(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("oprIf", "operator", false, args, adapters);
}

export function oprNot(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("oprNot", "operator", false, args, adapters);
}

export function oprOr(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("oprOr", "operator", false, args, adapters);
}

export function oprSubtract(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("oprSubtract", "operator", false, args, adapters);
}

export function toDouble(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("toDouble", "conversion", false, args, adapters);
}

export function toLong(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("toLong", "conversion", false, args, adapters);
}

export function toString(args: unknown[] = [], adapters: MakerRuntimeAdapters = {}): unknown {
  return evaluateByCategory("toString", "conversion", false, args, adapters);
}

function evaluateByCategory(name: string, category: string, adapterRequired: boolean, args: unknown[], adapters: MakerRuntimeAdapters): unknown {
  if (adapterRequired) {
    const adapter = adapters[name];
    if (!adapter) throw new Error(`${name} exige adapter de runtime antes da execucao`);
    return adapter(...args);
  }
  switch (category.toLowerCase()) {
    case "string":
      return args.map((value) => String(value ?? "")).join("");
    case "conversion": {
      const value = args[0];
      const numberValue = Number(value);
      return Number.isNaN(numberValue) ? String(value ?? "") : numberValue;
    }
    case "collection":
      return args;
    case "operator":
      if (args.length >= 2) return String(args[0]) === String(args[1]);
      throw new Error("Operador Maker precisa de parametros");
    default:
      throw new Error(`${name} precisa de revisao manual para categoria ${category}`);
  }
}
