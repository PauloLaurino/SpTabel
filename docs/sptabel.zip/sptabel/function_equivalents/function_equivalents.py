from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class MakerFunctionMeta:
    name: str
    category: str
    layer: str
    status: str
    adapter_required: bool
    description: str


FunctionAdapter = Callable[..., Any]

FUNCTION_CATALOG: dict[str, MakerFunctionMeta] = {
    "ebfappend": MakerFunctionMeta(name="ebfAppend", category="collection", layer="client", status="cataloged", adapter_required=False, description="Junta vários itens de texto em apenas um item."),
    "ebfchangecomponentvalueotherform": MakerFunctionMeta(name="ebfChangeComponentValueOtherForm", category="ui", layer="client", status="cataloged", adapter_required=True, description="Altera o valor de um componente que esteja em outro formulário que não o corrente."),
    "ebfcloseform": MakerFunctionMeta(name="ebfCloseForm", category="flow", layer="client", status="cataloged", adapter_required=True, description="Essa função é utilizada para fechar o formulário que chama o fluxo."),
    "ebfconcat": MakerFunctionMeta(name="ebfConcat", category="string", layer="client", status="cataloged", adapter_required=False, description="Junta vários itens de texto em apenas um item."),
    "ebfformatdatetime": MakerFunctionMeta(name="ebfFormatDateTime", category="date", layer="client", status="cataloged", adapter_required=False, description="Essa função modifica a formatação da data passada no primeiro parâmetro para a formatação passada no segundo parâmetro."),
    "ebfformchangecomponentvalue": MakerFunctionMeta(name="ebfFormChangeComponentValue", category="flow", layer="client", status="cataloged", adapter_required=True, description="A função altera o conteúdo do componente que está no formulário passado como parâmetro pelo conteúdo passado no 3º parâmetro."),
    "ebfformgetcomponentvalue": MakerFunctionMeta(name="ebfFormGetComponentValue", category="flow", layer="client", status="cataloged", adapter_required=True, description="Obtém o conteúdo do componente passado no segundo parâmetro e o retorna."),
    "ebfformgetlookupname": MakerFunctionMeta(name="ebfFormGetLookupName", category="ui", layer="client", status="cataloged", adapter_required=True, description="Função que obtém o valor exibido na lista dinâmica."),
    "ebfformopenfilteredform": MakerFunctionMeta(name="ebfFormOpenFilteredForm", category="ui", layer="server", status="cataloged", adapter_required=True, description="Form Open Filtered Form"),
    "ebfformopenform": MakerFunctionMeta(name="ebfFormOpenForm", category="ui", layer="client", status="cataloged", adapter_required=True, description="Abre o formulário passado por parâmetro."),
    "ebfformrefreshcomponent": MakerFunctionMeta(name="ebfFormRefreshComponent", category="flow", layer="client", status="cataloged", adapter_required=True, description="Atualiza o conteúdo do componente passado por parâmetro."),
    "ebfformsetenabled": MakerFunctionMeta(name="ebfFormSetEnabled", category="flow", layer="client", status="cataloged", adapter_required=True, description="Esta função habilita o componente se a condição passada no segundo parâmetro for verdadeira, ou desabilita caso a condição seja falsa. Se o componente estiver desabilitado, não será possível modificar seu conteúdo."),
    "ebfformsetfocus": MakerFunctionMeta(name="ebfFormSetFocus", category="flow", layer="client", status="cataloged", adapter_required=True, description="Essa função é utilizada para focar um determinado componente passado como parâmetro."),
    "ebfformsetlookupname": MakerFunctionMeta(name="ebfFormSetLookupName", category="ui", layer="client", status="cataloged", adapter_required=True, description="Função que altera o valor exibido na lista dinâmica."),
    "ebfformsetvisible": MakerFunctionMeta(name="ebfFormSetVisible", category="flow", layer="client", status="cataloged", adapter_required=True, description="Esta função mostra o componente se a condição passada no segundo parâmetro for verdadeira ou oculta caso a condição seja falsa."),
    "ebfgetcomponentvaluefromotherform": MakerFunctionMeta(name="ebfGetComponentValueFromOtherForm", category="ui", layer="client", status="cataloged", adapter_required=True, description="Nao detectado - revisao manual recomendada"),
    "ebfgetelementfromlist": MakerFunctionMeta(name="ebfGetElementFromList", category="collection", layer="client", status="cataloged", adapter_required=False, description="Essa função busca e retorna o elemento que deseja obter, a partir da sua posição na lista."),
    "ebfgetformresultset": MakerFunctionMeta(name="ebfGetFormResultset", category="ui", layer="server", status="cataloged", adapter_required=True, description="Get Form Resultset"),
    "ebfgetsessionattribute": MakerFunctionMeta(name="ebfGetSessionAttribute", category="math", layer="client", status="cataloged", adapter_required=False, description="Obtém o conteúdo da variável criada pela função \"Definir variável de sessão\" passando no 1º parâmetro o nome da variável e no 2º parâmetro o valor lógico verdadeiro ou falso, indicando se é ou não uma variável global. Para variáveis"),
    "ebfgetusercode": MakerFunctionMeta(name="ebfGetUserCode", category="system", layer="server", status="cataloged", adapter_required=True, description="Get User Code"),
    "ebfgridgetvalue": MakerFunctionMeta(name="ebfGridGetValue", category="grid", layer="client", status="cataloged", adapter_required=True, description="Essa função retorna o valor que está na Grade, a partir da informação da linha (a primeira linha da Grade é a linha \"0\" (zero)) e a coluna que deseja obter o valor."),
    "ebfgroupboxshowcomponents": MakerFunctionMeta(name="ebfGroupBoxShowComponents", category="ui", layer="client", status="cataloged", adapter_required=True, description="Esta função mostra ou oculta o componente moldura e todos os componentes que estiverem \"dentro\" da área do mesmo."),
    "ebfhtmlremovechild": MakerFunctionMeta(name="ebfHtmlRemoveChild", category="unknown", layer="client", status="cataloged", adapter_required=True, description="Esta função remove o filho de um elemento especificado por parâmetro."),
    "ebfindexof": MakerFunctionMeta(name="ebfIndexOf", category="unknown", layer="client", status="cataloged", adapter_required=True, description="Esta função localiza o conteúdo do 2° parâmetro dentro do conteúdo do primeiro parâmetro."),
    "ebflength": MakerFunctionMeta(name="ebfLength", category="unknown", layer="client", status="cataloged", adapter_required=True, description="A função recebe um texto e retorna o tamanho do mesmo."),
    "ebflistlength": MakerFunctionMeta(name="ebfListLength", category="collection", layer="client", status="cataloged", adapter_required=False, description="Essa função retorna o tamanho da lista, ou seja, a quantidade de elementos que pertencem à lista."),
    "ebflistparamscreate": MakerFunctionMeta(name="ebfListParamsCreate", category="collection", layer="client", status="cataloged", adapter_required=False, description="Essa função cria uma lista com todos os valores que foram passados pelos parâmetros."),
    "ebfnewline": MakerFunctionMeta(name="ebfNewLine", category="unknown", layer="client", status="cataloged", adapter_required=True, description="Usado para quebrar a linha (pular linha) em um texto, onde o parâmetro recebido será a quantidade de linhas à serem puladas."),
    "ebfrefreshcomponentotherform": MakerFunctionMeta(name="ebfRefreshComponentOtherForm", category="ui", layer="client", status="cataloged", adapter_required=True, description="Atualiza o componente em outro formulário."),
    "ebfremovesessionattribute": MakerFunctionMeta(name="ebfRemoveSessionAttribute", category="math", layer="client", status="cataloged", adapter_required=False, description="Remove a variável de sessão passando no 1º parâmetro o nome da variável e no 2º o valor Lógico que indica se ela é ou não global."),
    "ebfreplace": MakerFunctionMeta(name="ebfReplace", category="string", layer="client", status="cataloged", adapter_required=False, description="A função localiza o 2º parâmetro dentro do texto e o substitui pelo conteúdo passado no 3º parâmetro."),
    "ebfreplaceall": MakerFunctionMeta(name="ebfReplaceAll", category="string", layer="client", status="cataloged", adapter_required=False, description="Esta função localiza todas as subsequências iguais ao 2º parâmetro dentro do texto e os substituem pelo conteúdo passado no 3º parâmetro."),
    "ebfresultsetabsolute": MakerFunctionMeta(name="ebfResultSetAbsolute", category="system", layer="server", status="cataloged", adapter_required=True, description="Result Set Absolute"),
    "ebfrichtextinserttextatposition": MakerFunctionMeta(name="ebfRichTextInsertTextAtPosition", category="ui", layer="client", status="cataloged", adapter_required=True, description="Insere um texto na posição do cursor em um Texto Rico."),
    "ebfsearchsubstring": MakerFunctionMeta(name="ebfSearchSubstring", category="string", layer="client", status="cataloged", adapter_required=False, description="Esta função procura dentro do 1° parâmetro a subsequência passada no 2º parâmetro."),
    "ebfsetsessionattribute": MakerFunctionMeta(name="ebfSetSessionAttribute", category="ui", layer="client", status="cataloged", adapter_required=True, description="As variáveis de sessão são utilizadas quando houver a necessidade de ter uma variável que se mantém para regras diferentes. Variáveis de sessão não globais se mantém de acordo com o usuário e as globais se mantém para todo usuário."),
    "ebfsqlclose": MakerFunctionMeta(name="ebfSQLClose", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L Close"),
    "ebfsqlcommittransaction": MakerFunctionMeta(name="ebfSQLCommitTransaction", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L Commit Transaction"),
    "ebfsqleof": MakerFunctionMeta(name="ebfSQLEOF", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L E O F"),
    "ebfsqlexecutequery": MakerFunctionMeta(name="ebfSQLExecuteQuery", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L Execute Query"),
    "ebfsqlexecuteupdate": MakerFunctionMeta(name="ebfSQLExecuteUpdate", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L Execute Update"),
    "ebfsqlfield": MakerFunctionMeta(name="ebfSQLField", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L Field"),
    "ebfsqlgetfieldfromform": MakerFunctionMeta(name="ebfSQLGetFieldFromForm", category="flow", layer="client", status="cataloged", adapter_required=True, description="Obtém o conteúdo de um componente do formulário principal ou de qualquer outro passado por parâmetro."),
    "ebfsqlnext": MakerFunctionMeta(name="ebfSQLNext", category="database", layer="server", status="cataloged", adapter_required=True, description="S Q L Next"),
    "ebfstopruleexecution": MakerFunctionMeta(name="ebfStopRuleExecution", category="flow", layer="client", status="cataloged", adapter_required=True, description="Interrompe a execução do fluxo. Caso seja passado alguma mensagem por parâmetro, esta é exibida. Se houver algum processamento após a utilização dessa função, este não será executado."),
    "ebfsubstring": MakerFunctionMeta(name="ebfSubstring", category="string", layer="client", status="cataloged", adapter_required=False, description="A função recebe um texto (1º parâmetro) e retorna uma subsequência deste texto. A subsequência inicia na posição indicada no 2º parâmetro, com o tamanho indicado no 3º parâmetro."),
    "ebfsubstringinverse": MakerFunctionMeta(name="ebfSubstringInverse", category="string", layer="client", status="cataloged", adapter_required=False, description="A função recebe um texto (primeiro parâmetro) e retorna apenas a quantidade de caracteres passada no segundo"),
    "ebftrim": MakerFunctionMeta(name="ebfTrim", category="unknown", layer="client", status="cataloged", adapter_required=True, description="Remove os espaços existentes antes e depois do texto passado por parâmetro e retorna."),
    "isequal": MakerFunctionMeta(name="isEqual", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se os valores passados por parâmetro são iguais, ou seja, possuem o mesmo valor."),
    "isgreater": MakerFunctionMeta(name="isGreater", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se o valor do 1º parâmetro é maior que o do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso. Se os valores dos parâmetros forem iguais o retorno será falso, pois o mesmo valor não é maior que ele mesmo."),
    "isminor": MakerFunctionMeta(name="isMinor", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se o valor do 1º parâmetro é menor que o valor do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso. Se os valores dos parâmetros forem iguais o retorno será falso, pois o mesmo valor não é menor que ele mesmo."),
    "isminororequal": MakerFunctionMeta(name="isMinorOrEqual", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se o valor do 1º parâmetro é menor ou igual ao valor do 2º parâmetro. A depender do resultado retorna verdadeiro ou falso."),
    "isnullorempty": MakerFunctionMeta(name="isNullOrEmpty", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se o parâmetro é nulo ou vazio. A depender do resultado, retorna verdadeiro ou falso."),
    "l2sflowrunwithmessage": MakerFunctionMeta(name="l2sFlowRunWithMessage", category="unknown", layer="unknown", status="unknown", adapter_required=True, description="Nao detectado - revisao manual recomendada."),
    "opradd": MakerFunctionMeta(name="oprAdd", category="operator", layer="client", status="cataloged", adapter_required=False, description="Retorna a soma dos números passados por parâmetros."),
    "oprand": MakerFunctionMeta(name="oprAnd", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se algum valor passado é Falso, para retornar falso ou se são verdadeiros para retornar verdadeiro."),
    "oprif": MakerFunctionMeta(name="oprIf", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica o valor lógico do 1º parâmetro, se o mesmo for verdadeiro o retorno será o valor que estiver no 2º"),
    "oprnot": MakerFunctionMeta(name="oprNot", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função inverte o valor lógico. Se o valor do parâmetro for verdadeiro o retorno dele terá o valor lógico falso. Caso contrário será verdadeiro."),
    "opror": MakerFunctionMeta(name="oprOr", category="operator", layer="client", status="cataloged", adapter_required=False, description="Essa função verifica se algum valor passado por parâmetro é verdadeiro, para retornar verdadeiro ou se todos os parâmetros são valores falsos, para retornar falso."),
    "oprsubtract": MakerFunctionMeta(name="oprSubtract", category="operator", layer="client", status="cataloged", adapter_required=False, description="Subtração de valores informados nos parâmetros."),
    "todouble": MakerFunctionMeta(name="toDouble", category="conversion", layer="client", status="cataloged", adapter_required=False, description="Converte para fracionado o valor passado por parâmetro."),
    "tolong": MakerFunctionMeta(name="toLong", category="conversion", layer="client", status="cataloged", adapter_required=False, description="Converte um valor passado por parâmetro para Inteiro."),
    "tostring": MakerFunctionMeta(name="toString", category="conversion", layer="client", status="cataloged", adapter_required=False, description="Converte um valor passado por parâmetro para letras."),
}


def call_maker_equivalent(name: str, *args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    key = name.strip().lower()
    adapters = adapters or {}
    dispatch = {
        "ebfappend": ebf_append,
        "ebfchangecomponentvalueotherform": ebf_change_component_value_other_form,
        "ebfcloseform": ebf_close_form,
        "ebfconcat": ebf_concat,
        "ebfformatdatetime": ebf_format_date_time,
        "ebfformchangecomponentvalue": ebf_form_change_component_value,
        "ebfformgetcomponentvalue": ebf_form_get_component_value,
        "ebfformgetlookupname": ebf_form_get_lookup_name,
        "ebfformopenfilteredform": ebf_form_open_filtered_form,
        "ebfformopenform": ebf_form_open_form,
        "ebfformrefreshcomponent": ebf_form_refresh_component,
        "ebfformsetenabled": ebf_form_set_enabled,
        "ebfformsetfocus": ebf_form_set_focus,
        "ebfformsetlookupname": ebf_form_set_lookup_name,
        "ebfformsetvisible": ebf_form_set_visible,
        "ebfgetcomponentvaluefromotherform": ebf_get_component_value_from_other_form,
        "ebfgetelementfromlist": ebf_get_element_from_list,
        "ebfgetformresultset": ebf_get_form_resultset,
        "ebfgetsessionattribute": ebf_get_session_attribute,
        "ebfgetusercode": ebf_get_user_code,
        "ebfgridgetvalue": ebf_grid_get_value,
        "ebfgroupboxshowcomponents": ebf_group_box_show_components,
        "ebfhtmlremovechild": ebf_html_remove_child,
        "ebfindexof": ebf_index_of,
        "ebflength": ebf_length,
        "ebflistlength": ebf_list_length,
        "ebflistparamscreate": ebf_list_params_create,
        "ebfnewline": ebf_new_line,
        "ebfrefreshcomponentotherform": ebf_refresh_component_other_form,
        "ebfremovesessionattribute": ebf_remove_session_attribute,
        "ebfreplace": ebf_replace,
        "ebfreplaceall": ebf_replace_all,
        "ebfresultsetabsolute": ebf_result_set_absolute,
        "ebfrichtextinserttextatposition": ebf_rich_text_insert_text_at_position,
        "ebfsearchsubstring": ebf_search_substring,
        "ebfsetsessionattribute": ebf_set_session_attribute,
        "ebfsqlclose": ebf_s_q_l_close,
        "ebfsqlcommittransaction": ebf_s_q_l_commit_transaction,
        "ebfsqleof": ebf_s_q_l_e_o_f,
        "ebfsqlexecutequery": ebf_s_q_l_execute_query,
        "ebfsqlexecuteupdate": ebf_s_q_l_execute_update,
        "ebfsqlfield": ebf_s_q_l_field,
        "ebfsqlgetfieldfromform": ebf_s_q_l_get_field_from_form,
        "ebfsqlnext": ebf_s_q_l_next,
        "ebfstopruleexecution": ebf_stop_rule_execution,
        "ebfsubstring": ebf_substring,
        "ebfsubstringinverse": ebf_substring_inverse,
        "ebftrim": ebf_trim,
        "isequal": is_equal,
        "isgreater": is_greater,
        "isminor": is_minor,
        "isminororequal": is_minor_or_equal,
        "isnullorempty": is_null_or_empty,
        "l2sflowrunwithmessage": l2s_flow_run_with_message,
        "opradd": opr_add,
        "oprand": opr_and,
        "oprif": opr_if,
        "oprnot": opr_not,
        "opror": opr_or,
        "oprsubtract": opr_subtract,
        "todouble": to_double,
        "tolong": to_long,
        "tostring": to_string,
    }
    if key not in dispatch:
        raise KeyError(f"Funcao Maker nao catalogada: {name}")
    return dispatch[key](*args, adapters=adapters)


def ebf_append(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfAppend", "collection", False, list(args), adapters or {})


def ebf_change_component_value_other_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfChangeComponentValueOtherForm", "ui", True, list(args), adapters or {})


def ebf_close_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfCloseForm", "flow", True, list(args), adapters or {})


def ebf_concat(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfConcat", "string", False, list(args), adapters or {})


def ebf_format_date_time(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormatDateTime", "date", False, list(args), adapters or {})


def ebf_form_change_component_value(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormChangeComponentValue", "flow", True, list(args), adapters or {})


def ebf_form_get_component_value(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormGetComponentValue", "flow", True, list(args), adapters or {})


def ebf_form_get_lookup_name(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormGetLookupName", "ui", True, list(args), adapters or {})


def ebf_form_open_filtered_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormOpenFilteredForm", "ui", True, list(args), adapters or {})


def ebf_form_open_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormOpenForm", "ui", True, list(args), adapters or {})


def ebf_form_refresh_component(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormRefreshComponent", "flow", True, list(args), adapters or {})


def ebf_form_set_enabled(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormSetEnabled", "flow", True, list(args), adapters or {})


def ebf_form_set_focus(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormSetFocus", "flow", True, list(args), adapters or {})


def ebf_form_set_lookup_name(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormSetLookupName", "ui", True, list(args), adapters or {})


def ebf_form_set_visible(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfFormSetVisible", "flow", True, list(args), adapters or {})


def ebf_get_component_value_from_other_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGetComponentValueFromOtherForm", "ui", True, list(args), adapters or {})


def ebf_get_element_from_list(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGetElementFromList", "collection", False, list(args), adapters or {})


def ebf_get_form_resultset(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGetFormResultset", "ui", True, list(args), adapters or {})


def ebf_get_session_attribute(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGetSessionAttribute", "math", False, list(args), adapters or {})


def ebf_get_user_code(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGetUserCode", "system", True, list(args), adapters or {})


def ebf_grid_get_value(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGridGetValue", "grid", True, list(args), adapters or {})


def ebf_group_box_show_components(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfGroupBoxShowComponents", "ui", True, list(args), adapters or {})


def ebf_html_remove_child(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfHtmlRemoveChild", "unknown", True, list(args), adapters or {})


def ebf_index_of(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfIndexOf", "unknown", True, list(args), adapters or {})


def ebf_length(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfLength", "unknown", True, list(args), adapters or {})


def ebf_list_length(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfListLength", "collection", False, list(args), adapters or {})


def ebf_list_params_create(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfListParamsCreate", "collection", False, list(args), adapters or {})


def ebf_new_line(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfNewLine", "unknown", True, list(args), adapters or {})


def ebf_refresh_component_other_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfRefreshComponentOtherForm", "ui", True, list(args), adapters or {})


def ebf_remove_session_attribute(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfRemoveSessionAttribute", "math", False, list(args), adapters or {})


def ebf_replace(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfReplace", "string", False, list(args), adapters or {})


def ebf_replace_all(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfReplaceAll", "string", False, list(args), adapters or {})


def ebf_result_set_absolute(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfResultSetAbsolute", "system", True, list(args), adapters or {})


def ebf_rich_text_insert_text_at_position(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfRichTextInsertTextAtPosition", "ui", True, list(args), adapters or {})


def ebf_search_substring(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSearchSubstring", "string", False, list(args), adapters or {})


def ebf_set_session_attribute(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSetSessionAttribute", "ui", True, list(args), adapters or {})


def ebf_s_q_l_close(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLClose", "database", True, list(args), adapters or {})


def ebf_s_q_l_commit_transaction(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLCommitTransaction", "database", True, list(args), adapters or {})


def ebf_s_q_l_e_o_f(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLEOF", "database", True, list(args), adapters or {})


def ebf_s_q_l_execute_query(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLExecuteQuery", "database", True, list(args), adapters or {})


def ebf_s_q_l_execute_update(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLExecuteUpdate", "database", True, list(args), adapters or {})


def ebf_s_q_l_field(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLField", "database", True, list(args), adapters or {})


def ebf_s_q_l_get_field_from_form(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLGetFieldFromForm", "flow", True, list(args), adapters or {})


def ebf_s_q_l_next(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSQLNext", "database", True, list(args), adapters or {})


def ebf_stop_rule_execution(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfStopRuleExecution", "flow", True, list(args), adapters or {})


def ebf_substring(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSubstring", "string", False, list(args), adapters or {})


def ebf_substring_inverse(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfSubstringInverse", "string", False, list(args), adapters or {})


def ebf_trim(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("ebfTrim", "unknown", True, list(args), adapters or {})


def is_equal(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("isEqual", "operator", False, list(args), adapters or {})


def is_greater(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("isGreater", "operator", False, list(args), adapters or {})


def is_minor(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("isMinor", "operator", False, list(args), adapters or {})


def is_minor_or_equal(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("isMinorOrEqual", "operator", False, list(args), adapters or {})


def is_null_or_empty(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("isNullOrEmpty", "operator", False, list(args), adapters or {})


def l2s_flow_run_with_message(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("l2sFlowRunWithMessage", "unknown", True, list(args), adapters or {})


def opr_add(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("oprAdd", "operator", False, list(args), adapters or {})


def opr_and(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("oprAnd", "operator", False, list(args), adapters or {})


def opr_if(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("oprIf", "operator", False, list(args), adapters or {})


def opr_not(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("oprNot", "operator", False, list(args), adapters or {})


def opr_or(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("oprOr", "operator", False, list(args), adapters or {})


def opr_subtract(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("oprSubtract", "operator", False, list(args), adapters or {})


def to_double(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("toDouble", "conversion", False, list(args), adapters or {})


def to_long(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("toLong", "conversion", False, list(args), adapters or {})


def to_string(*args: Any, adapters: dict[str, FunctionAdapter] | None = None) -> Any:
    return _evaluate_by_category("toString", "conversion", False, list(args), adapters or {})


def _evaluate_by_category(name: str, category: str, adapter_required: bool, args: list[Any], adapters: dict[str, FunctionAdapter]) -> Any:
    if adapter_required:
        adapter = adapters.get(name)
        if adapter is None:
            raise RuntimeError(f"{name} exige adapter de runtime antes da execucao")
        return adapter(*args)
    normalized = category.lower()
    if normalized == "string":
        return "".join("" if value is None else str(value) for value in args)
    if normalized == "conversion":
        if not args:
            return None
        try:
            return float(args[0])
        except (TypeError, ValueError):
            return "" if args[0] is None else str(args[0])
    if normalized == "collection":
        return args
    if normalized == "operator":
        if len(args) >= 2:
            return str(args[0]) == str(args[1])
        raise ValueError("Operador Maker precisa de parametros")
    raise RuntimeError(f"{name} precisa de revisao manual para categoria {category}")
