# Prompt premium fullstack - M003 - Editor

```prompt
Voce e um arquiteto senior. Gere a tela equivalente ao FRZ Maker/WebRun analisado.

Modulo: M003 - Editor
Arquivo FRZ: Editor.frz
Metricas reais: formularios=5, componentes=162, eventos=47, regras=31, fluxos=31, queries=20, tabelas=9, submodulos=0.
Estimativa: 148.5 pontos de funcao, faixa 126.2 a 178.2.

Subformularios e grids detectados:
- Nao detectado - revisao manual recomendada.

Funcoes ainda sem equivalente catalogado:
- l2sFlowRunWithMessage

Integracoes criticas identificadas:
- Nao detectado - revisao manual recomendada.

Entregue:
- Backend em Go usando Handler -> Service -> Repository.
- Banco multi-tenant, com codi_empre obrigatorio em todas as queries.
- Autenticacao JWT e autorizacao por empresa.
- Frontend TypeScript com formularios, grids filhos, validacoes e estados de carregamento.
- Contratos de API, DTOs, modelos, migrations e testes dos fluxos criticos.
- Mock HTML navegavel da tela para validacao com usuario antes da implementacao final.
- Onde a regra Maker depender de runtime WebRun, crie adapter explicito e marque pontos de revisao manual.
```
